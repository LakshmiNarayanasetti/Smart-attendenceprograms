/**
 * Comprehensive End-to-End System Verification Suite
 * Tests all 31 core system requirements for the Smart Attendance System.
 */

const http = require('http');

const PORT = process.env.PORT || 5000;
const BASE_URL = `http://localhost:${PORT}`;

function makeRequest(path, method = 'GET', body = null, token = null) {
  return new Promise((resolve, reject) => {
    const url = new URL(path, BASE_URL);
    const headers = {};

    if (body) {
      headers['Content-Type'] = 'application/json';
    }
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const req = http.request(
      url,
      {
        method,
        headers
      },
      (res) => {
        let rawData = '';
        res.on('data', (chunk) => (rawData += chunk));
        res.on('end', () => {
          try {
            const parsed = JSON.parse(rawData);
            resolve({ statusCode: res.statusCode, headers: res.headers, body: parsed });
          } catch (e) {
            resolve({ statusCode: res.statusCode, headers: res.headers, raw: rawData });
          }
        });
      }
    );

    req.on('error', (e) => reject(e));

    if (body) {
      req.write(JSON.stringify(body));
    }
    req.end();
  });
}

function createNormalizedDescriptor(seed = 42) {
  const descriptor = [];
  let sumSq = 0;
  for (let i = 0; i < 128; i++) {
    const val = Math.sin(seed + i * 0.1) * 0.5;
    descriptor.push(val);
    sumSq += val * val;
  }
  const norm = Math.sqrt(sumSq);
  return descriptor.map((v) => Number((v / norm).toFixed(5)));
}

async function runCompleteTestSuite() {
  console.log('================================================================');
  console.log('   STARTING COMPLETE SMART ATTENDANCE SYSTEM VERIFICATION');
  console.log('================================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`  ✓ PASS: ${message}`);
      passed++;
    } else {
      console.error(`  ✗ FAIL: ${message}`);
      failed++;
    }
  }

  try {
    // -------------------------------------------------------------
    // Phase 1: Health & Database Connectivity
    // -------------------------------------------------------------
    console.log('[Phase 1]: System Health & Database Connectivity');
    const health = await makeRequest('/api/health');
    assert(health.statusCode === 200, 'Health endpoint returned HTTP 200');
    assert(health.body.database === 'connected', 'MongoDB connection is actively established');

    // -------------------------------------------------------------
    // Phase 2: Role Authentication (Student, Teacher, Admin)
    // -------------------------------------------------------------
    console.log('\n[Phase 2]: Role-Based Authentication & Session Issuance');

    // Admin login
    const adminLogin = await makeRequest('/api/auth/login', 'POST', {
      email: 'admin@college.edu',
      password: 'Admin@12345',
      role: 'admin'
    });
    assert(adminLogin.statusCode === 200, 'Admin login succeeded');
    const adminToken = adminLogin.body.token;

    // Teacher login
    const teacherLogin = await makeRequest('/api/auth/login', 'POST', {
      email: 'teacher@college.edu',
      password: 'Teacher@12345',
      role: 'teacher'
    });
    assert(teacherLogin.statusCode === 200, 'Teacher login succeeded');
    const teacherToken = teacherLogin.body.token;

    // Student login
    const studentLogin = await makeRequest('/api/auth/login', 'POST', {
      email: 'student@college.edu',
      password: 'Student@12345',
      role: 'student'
    });
    assert(studentLogin.statusCode === 200, 'Student login succeeded');
    const studentToken = studentLogin.body.token;
    const studentId = studentLogin.body.user._id;

    // -------------------------------------------------------------
    // Phase 3: Location Engines (GPS Campus Geofence & Wi-Fi Indoor)
    // -------------------------------------------------------------
    console.log('\n[Phase 3]: GPS Campus Boundary & Wi-Fi Indoor Positioning');

    // GPS Inside Campus (12.971598, 77.594562)
    const gpsInside = await makeRequest('/api/location/check-gps', 'POST', {
      latitude: 12.971598,
      longitude: 77.594562
    }, studentToken);
    assert(gpsInside.statusCode === 200, 'GPS check endpoint responded (200)');
    assert(gpsInside.body.inCampus === true, 'Coordinates verified inside campus boundary');
    assert(gpsInside.body.distanceMeters <= 50, 'Distance from campus center calculated accurately (~0m)');

    // GPS Outside Campus (e.g. 50 km away)
    const gpsOutside = await makeRequest('/api/location/check-gps', 'POST', {
      latitude: 13.500000,
      longitude: 78.200000
    }, studentToken);
    assert(gpsOutside.body.inCampus === false, 'Student outside campus correctly rejected by GPS geofence');

    // Wi-Fi Indoor Positioning (Building -> Floor -> Room)
    const wifiRes = await makeRequest('/api/location/resolve-wifi', 'POST', {
      scanData: { bssid: '00:1A:2B:3C:4D:01', rssi: -65, ssid: 'CAMPUS-CS-LAB-101' }
    }, studentToken);
    assert(wifiRes.statusCode === 200, 'Wi-Fi indoor resolution succeeded');
    assert(wifiRes.body.location.building.name.includes('Aryabhata'), 'Correct Building resolved from AP BSSID');
    assert(wifiRes.body.location.floor.floorName === '1st Floor', 'Correct Floor resolved (1st Floor)');
    assert(wifiRes.body.location.classroom.roomNumber === '101', 'Correct Room resolved (Room 101)');

    // Wi-Fi Demo Access Points List
    const demoAps = await makeRequest('/api/location/demo-aps');
    assert(demoAps.statusCode === 200, 'Demo APs endpoint returned list for DEMO WIFI MODE');
    assert(demoAps.body.accessPoints.length >= 3, 'Multiple campus AP mappings available for simulation');

    // Android Wi-Fi scan ingestion endpoint
    const androidScan = await makeRequest('/api/location/wifi-scan', 'POST', {
      deviceModel: 'Pixel 8 Android Companion',
      scans: [
        { bssid: '00:1A:2B:3C:4D:01', ssid: 'CAMPUS-CS-LAB-101', rssi: -60 }
      ]
    }, studentToken);
    assert(androidScan.statusCode === 200, 'Android companion Wi-Fi scan successfully ingested');
    assert(androidScan.body.resolution.building.code === 'ENG-A', 'Android scan resolved Building code ENG-A');

    // -------------------------------------------------------------
    // Phase 4: Biometric Face & QR Profile Services
    // -------------------------------------------------------------
    console.log('\n[Phase 4]: Facial Biometrics & Identification QR Code');

    // Student QR Code
    const studentQr = await makeRequest('/api/student/my-qr', 'GET', null, studentToken);
    assert(studentQr.statusCode === 200, 'Personal QR generation succeeded');
    assert(Boolean(studentQr.body.qrDataUrl), 'Base64 QR image generated without sensitive leaks');
    assert(studentQr.body.rollNumber === 'CS2026-001', 'QR metadata matches enrolled student roll number');

    // Student Face Biometrics
    const testDescriptor = createNormalizedDescriptor(42);
    const faceReg = await makeRequest('/api/student/face-descriptor', 'POST', {
      descriptor: testDescriptor
    }, studentToken);
    assert(faceReg.statusCode === 200, 'Biometric face descriptor saved to profile');

    // -------------------------------------------------------------
    // Phase 5: Teacher Live Class Session & Dynamic QR Screen
    // -------------------------------------------------------------
    console.log('\n[Phase 5]: Teacher Session Lifecycle & Dynamic Classroom QR');

    const teacherClasses = await makeRequest('/api/teacher/classes', 'GET', null, teacherToken);
    assert(teacherClasses.statusCode === 200, 'Teacher classes and classrooms retrieved');
    const targetSubject = teacherClasses.body.subjects[0];
    const targetRoom = teacherClasses.body.classrooms.find(r => r.roomNumber === '101');

    // Teacher starts live session
    const startSession = await makeRequest('/api/teacher/sessions', 'POST', {
      subjectId: targetSubject._id,
      classroomId: targetRoom._id
    }, teacherToken);
    assert(startSession.statusCode === 201, 'Live attendance session created');
    assert(Boolean(startSession.body.session.qrDataUrl), 'Classroom projector dynamic QR code generated');
    const sessionId = startSession.body.session._id;
    const sessionQrToken = startSession.body.session.sessionQrToken;

    // -------------------------------------------------------------
    // Phase 6: Multi-Factor Attendance Verification & Validation
    // -------------------------------------------------------------
    console.log('\n[Phase 6]: Multi-Factor Attendance Verification Pipeline');

    // 1. Submit Valid Attendance Check-In
    const validCheckin = await makeRequest('/api/attendance/verify', 'POST', {
      sessionId,
      qrToken: sessionQrToken,
      faceDescriptor: testDescriptor,
      gpsCoords: { latitude: 12.971598, longitude: 77.594562 },
      wifiScan: { bssid: '00:1A:2B:3C:4D:01', rssi: -62, ssid: 'CAMPUS-CS-LAB-101' },
      isDemoMode: true
    }, studentToken);
    assert(validCheckin.statusCode === 201, 'Full multi-factor attendance verification succeeded (201)');
    assert(validCheckin.body.attendance.status === 'Present', 'Status recorded as Present');
    assert(validCheckin.body.attendance.verificationSteps.qrScanned.verified === true, 'QR verified in audit trail');
    assert(validCheckin.body.attendance.verificationSteps.faceRecognition.verified === true, 'Face verified in audit trail');
    assert(validCheckin.body.attendance.verificationSteps.gpsCampus.verified === true, 'GPS verified in audit trail');
    assert(validCheckin.body.attendance.verificationSteps.wifiIndoor.verified === true, 'Wi-Fi indoor verified in audit trail');
    assert(validCheckin.body.attendance.verificationSteps.classroomMatch.verified === true, 'Classroom match verified');
    const attendanceRecordId = validCheckin.body.attendance._id;

    // 2. DUPLICATE ATTENDANCE PREVENTION
    console.log('\n[Phase 7]: Duplicate Attendance Prevention');
    const duplicateCheckin = await makeRequest('/api/attendance/verify', 'POST', {
      sessionId,
      qrToken: sessionQrToken,
      faceDescriptor: testDescriptor,
      gpsCoords: { latitude: 12.971598, longitude: 77.594562 },
      wifiScan: { bssid: '00:1A:2B:3C:4D:01', rssi: -62, ssid: 'CAMPUS-CS-LAB-101' },
      isDemoMode: true
    }, studentToken);
    assert(duplicateCheckin.statusCode === 409, 'Duplicate attendance blocked with HTTP 409 Conflict');

    // 3. Location Mismatch Rejection (Wrong Classroom Wi-Fi)
    console.log('\n[Phase 8]: Negative Testing (Location & Biometric Mismatch)');
    // Register another test student to test negative checks without hit by duplicate prevention
    const student2Roll = `CS2026_${Math.floor(1000 + Math.random() * 9000)}`;
    const student2Reg = await makeRequest('/api/auth/register', 'POST', {
      name: 'Pooja Verma',
      email: `pooja_${Date.now()}@college.edu`,
      rollNumber: student2Roll,
      password: 'Password@123'
    });
    const student2Token = student2Reg.body.token;
    await makeRequest('/api/student/face-descriptor', 'POST', { descriptor: testDescriptor }, student2Token);

    // Test with AP located in Room 201 (Lecture Hall) when class is in Room 101
    const mismatchLocation = await makeRequest('/api/attendance/verify', 'POST', {
      sessionId,
      qrToken: sessionQrToken,
      faceDescriptor: testDescriptor,
      gpsCoords: { latitude: 12.971598, longitude: 77.594562 },
      wifiScan: { bssid: '00:1A:2B:3C:4D:02', rssi: -60 }, // Room 201 AP
      isDemoMode: true
    }, student2Token);
    assert(mismatchLocation.statusCode === 403, 'Rejected when student is on wrong floor/room (403)');
    assert(mismatchLocation.body.stepFailed === 'CLASSROOM_MISMATCH', 'Failure step correctly identified as CLASSROOM_MISMATCH');

    // -------------------------------------------------------------
    // Phase 9: Real-Time Monitoring & Faculty Controls
    // -------------------------------------------------------------
    console.log('\n[Phase 9]: Live Attendance Feed & Teacher Override');

    const liveFeed = await makeRequest(`/api/attendance/session/${sessionId}`, 'GET', null, teacherToken);
    assert(liveFeed.statusCode === 200, 'Teacher live attendance feed retrieved');
    assert(liveFeed.body.totalCount >= 1, 'Live attendance count reflects checked-in student');

    // Teacher updates status / remark
    const statusUpdate = await makeRequest(`/api/attendance/${attendanceRecordId}`, 'PATCH', {
      status: 'Present',
      teacherRemark: 'Verified by Instructor in Room 101'
    }, teacherToken);
    assert(statusUpdate.statusCode === 200, 'Teacher override / remark saved');

    // -------------------------------------------------------------
    // Phase 10: Reports & Attendance Percentages
    // -------------------------------------------------------------
    console.log('\n[Phase 10]: Attendance Reports & Percentage Calculations');

    // Student History
    const stuHistory = await makeRequest('/api/attendance/my-history', 'GET', null, studentToken);
    assert(stuHistory.statusCode === 200, 'Student personal attendance history retrieved');
    assert(stuHistory.body.overallPercentage > 0, 'Overall percentage dynamically computed');
    assert(stuHistory.body.subjectWiseReports.length > 0, 'Subject-wise percentage breakdown computed');

    // Teacher / Admin Global Reports
    const adminReports = await makeRequest('/api/attendance/reports', 'GET', null, adminToken);
    assert(adminReports.statusCode === 200, 'Admin global attendance reports generated');
    assert(adminReports.body.studentReports.length > 0, 'Student-wise summary aggregated');
    assert(adminReports.body.subjectReports.length > 0, 'Subject-wise summary aggregated');

    // -------------------------------------------------------------
    // Phase 11: Admin Infrastructure & AP Management
    // -------------------------------------------------------------
    console.log('\n[Phase 11]: Administrative Infrastructure & AP Management');

    const adminStats = await makeRequest('/api/admin/stats', 'GET', null, adminToken);
    assert(adminStats.statusCode === 200, 'System stats retrieved');
    assert(adminStats.body.stats.totalStudents >= 1, 'Total students counted');
    assert(adminStats.body.stats.totalRooms >= 3, 'Classrooms counted');

    const campusGet = await makeRequest('/api/admin/campus', 'GET', null, adminToken);
    assert(campusGet.statusCode === 200, 'Campus configuration retrieved');

    const infrastructure = await makeRequest('/api/admin/infrastructure', 'GET', null, adminToken);
    assert(infrastructure.statusCode === 200, 'Campus infrastructure hierarchy retrieved');
    assert(infrastructure.body.buildings.length >= 2, 'Buildings list loaded');
    assert(infrastructure.body.floors.length >= 3, 'Floors list loaded');
    assert(infrastructure.body.classrooms.length >= 3, 'Classrooms list loaded');

    console.log('\n================================================================');
    console.log(`   SYSTEM VERIFICATION COMPLETE: ${passed} PASSED, ${failed} FAILED`);
    console.log('================================================================\n');

    process.exit(failed > 0 ? 1 : 0);
  } catch (error) {
    console.error('Fatal error during test run:', error);
    process.exit(1);
  }
}

runCompleteTestSuite();
