const express = require('express');
const router = express.Router();
const {
  checkCampusGps,
  resolveWifi,
  getDemoAccessPoints,
  ingestAndroidScan
} = require('../controllers/locationController');
const { protect } = require('../middleware/auth');

// Public or student-accessible Demo Wi-Fi Access Points list
router.get('/demo-aps', getDemoAccessPoints);

// Protected location verification routes
router.post('/check-gps', protect, checkCampusGps);
router.post('/resolve-wifi', protect, resolveWifi);
router.post('/wifi-scan', protect, ingestAndroidScan);

module.exports = router;
