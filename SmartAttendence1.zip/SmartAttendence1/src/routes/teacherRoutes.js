const express = require('express');
const router = express.Router();
const {
  getTeacherClasses,
  createAttendanceSession,
  getSessionDetails,
  closeAttendanceSession
} = require('../controllers/teacherController');
const { protect, authorizeRoles } = require('../middleware/auth');

router.use(protect);
router.use(authorizeRoles('teacher', 'admin'));

router.get('/classes', getTeacherClasses);
router.post('/sessions', createAttendanceSession);
router.get('/sessions/:id', getSessionDetails);
router.patch('/sessions/:id/close', closeAttendanceSession);

module.exports = router;
