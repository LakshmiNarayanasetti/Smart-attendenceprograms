const express = require('express');
const router = express.Router();
const {
  registerStudent,
  login,
  getMe
} = require('../controllers/authController');
const { protect, authorizeRoles } = require('../middleware/auth');

// Public routes
router.post('/register', registerStudent);
router.post('/login', login);

// Protected routes
router.get('/me', protect, getMe);

// Verification routes for testing role guards (used during Stage 1 automated tests)
router.get('/test/student', protect, authorizeRoles('student'), (req, res) => {
  res.json({ success: true, message: 'Student access verified.', user: req.user });
});

router.get('/test/teacher', protect, authorizeRoles('teacher'), (req, res) => {
  res.json({ success: true, message: 'Teacher access verified.', user: req.user });
});

router.get('/test/admin', protect, authorizeRoles('admin'), (req, res) => {
  res.json({ success: true, message: 'Admin access verified.', user: req.user });
});

module.exports = router;
