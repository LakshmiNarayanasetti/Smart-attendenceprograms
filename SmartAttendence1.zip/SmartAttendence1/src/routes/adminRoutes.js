const express = require('express');
const router = express.Router();
const {
  getSystemStats,
  getCampusConfig,
  updateCampusConfig,
  getInfrastructure,
  createBuilding,
  createFloor,
  createClassroom,
  getAccessPoints,
  createAccessPoint,
  deleteAccessPoint,
  getSubjects,
  createSubject,
  getUsers,
  createUser
} = require('../controllers/adminController');
const { protect, authorizeRoles } = require('../middleware/auth');

router.use(protect);
router.use(authorizeRoles('admin'));

// System stats
router.get('/stats', getSystemStats);

// Campus GPS Geofence Configuration
router.get('/campus', getCampusConfig);
router.put('/campus', updateCampusConfig);

// Infrastructure (Buildings, Floors, Classrooms)
router.get('/infrastructure', getInfrastructure);
router.post('/buildings', createBuilding);
router.post('/floors', createFloor);
router.post('/classrooms', createClassroom);

// Wi-Fi Access Points
router.get('/access-points', getAccessPoints);
router.post('/access-points', createAccessPoint);
router.delete('/access-points/:id', deleteAccessPoint);

// Subjects / Curriculum
router.get('/subjects', getSubjects);
router.post('/subjects', createSubject);

// Users (Students, Teachers, Admins)
router.get('/users', getUsers);
router.post('/users', createUser);

module.exports = router;
