const express = require('express');
const router = express.Router();
const {
  submitAttendance,
  getMyAttendanceHistory,
  getSessionAttendance,
  updateAttendanceStatus,
  getAttendanceReports,
  verifyStudentQrCode
} = require('../controllers/attendanceController');
const { protect, authorizeRoles } = require('../middleware/auth');

// QR Scanning & Student Identification verification
router.post('/scan-student-qr', protect, verifyStudentQrCode);

// Student attendance verification submission & personal history
router.post('/verify', protect, authorizeRoles('student'), submitAttendance);
router.get('/my-history', protect, authorizeRoles('student'), getMyAttendanceHistory);

// Teacher & Admin live session monitor and reports
router.get('/session/:sessionId', protect, authorizeRoles('teacher', 'admin'), getSessionAttendance);
router.patch('/:id', protect, authorizeRoles('teacher', 'admin'), updateAttendanceStatus);
router.get('/reports', protect, authorizeRoles('teacher', 'admin'), getAttendanceReports);

module.exports = router;
