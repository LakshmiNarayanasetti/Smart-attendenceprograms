const express = require('express');
const router = express.Router();
const {
  registerFaceDescriptor,
  getMyQrCode,
  updateProfile,
  getActiveSessions
} = require('../controllers/studentController');
const { protect, authorizeRoles } = require('../middleware/auth');

router.use(protect);
router.use(authorizeRoles('student'));

router.post('/face-descriptor', registerFaceDescriptor);
router.get('/my-qr', getMyQrCode);
router.patch('/profile', updateProfile);
router.get('/active-sessions', getActiveSessions);

module.exports = router;
