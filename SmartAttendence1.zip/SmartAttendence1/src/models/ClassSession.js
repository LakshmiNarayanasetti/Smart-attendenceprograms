const mongoose = require('mongoose');

const classSessionSchema = new mongoose.Schema(
  {
    subject: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subject',
      required: true
    },
    teacher: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    classroom: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Classroom',
      required: true
    },
    sessionCode: {
      type: String,
      required: true,
      unique: true,
      uppercase: true,
      trim: true
    },
    sessionQrToken: {
      type: String,
      required: true,
      unique: true
    },
    date: {
      type: Date,
      default: Date.now
    },
    startTime: {
      type: Date,
      default: Date.now
    },
    endTime: {
      type: Date
    },
    status: {
      type: String,
      enum: ['active', 'closed'],
      default: 'active'
    },
    allowedRadiusMeters: {
      type: Number,
      default: 600 // Campus GPS geofence threshold
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model('ClassSession', classSessionSchema);
