const mongoose = require('mongoose');

const classroomSchema = new mongoose.Schema(
  {
    roomNumber: {
      type: String,
      required: [true, 'Please provide room number'],
      trim: true // e.g. "101", "204"
    },
    name: {
      type: String,
      required: [true, 'Please provide classroom/lab name'],
      trim: true // e.g. "CS Lab 1", "Lecture Hall 101"
    },
    building: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Building',
      required: true
    },
    floor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Floor',
      required: true
    },
    capacity: {
      type: Number,
      default: 60
    },
    type: {
      type: String,
      enum: ['Classroom', 'Computer Lab', 'Lecture Hall', 'Seminar Hall'],
      default: 'Classroom'
    }
  },
  { timestamps: true }
);

// Prevent duplicate room numbers on the same floor
classroomSchema.index({ floor: 1, roomNumber: 1 }, { unique: true });

module.exports = mongoose.model('Classroom', classroomSchema);
