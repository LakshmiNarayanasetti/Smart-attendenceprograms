const mongoose = require('mongoose');

const buildingSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Please provide building name'],
      trim: true
    },
    code: {
      type: String,
      required: [true, 'Please provide building code'],
      uppercase: true,
      trim: true,
      unique: true
    },
    campus: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Campus',
      required: true
    },
    totalFloors: {
      type: Number,
      default: 4
    },
    description: {
      type: String,
      default: ''
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Building', buildingSchema);
