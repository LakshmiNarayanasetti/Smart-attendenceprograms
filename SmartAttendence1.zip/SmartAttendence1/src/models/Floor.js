const mongoose = require('mongoose');

const floorSchema = new mongoose.Schema(
  {
    building: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Building',
      required: true
    },
    floorNumber: {
      type: Number,
      required: true // 0 = Ground Floor, 1 = 1st Floor, etc.
    },
    floorName: {
      type: String,
      required: true,
      trim: true // e.g. "Ground Floor", "1st Floor"
    },
    description: {
      type: String,
      default: ''
    }
  },
  { timestamps: true }
);

// Prevent duplicate floor numbers in the same building
floorSchema.index({ building: 1, floorNumber: 1 }, { unique: true });

module.exports = mongoose.model('Floor', floorSchema);
