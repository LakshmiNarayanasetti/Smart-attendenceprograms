const mongoose = require('mongoose');

const attendanceSchema = new mongoose.Schema(
  {
    student: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    session: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'ClassSession',
      required: true
    },
    subject: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subject',
      required: true
    },
    classroom: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Classroom',
      required: true
    },
    timestamp: {
      type: Date,
      default: Date.now
    },
    status: {
      type: String,
      enum: ['Present', 'Late', 'Flagged', 'Rejected'],
      default: 'Present'
    },
    // Multi-factor verification audit trail
    verificationSteps: {
      qrScanned: {
        verified: { type: Boolean, default: false },
        tokenValue: { type: String, default: '' },
        verifiedAt: { type: Date }
      },
      faceRecognition: {
        verified: { type: Boolean, default: false },
        confidenceScore: { type: Number, default: 0 },
        verifiedAt: { type: Date }
      },
      gpsCampus: {
        verified: { type: Boolean, default: false },
        latitude: { type: Number },
        longitude: { type: Number },
        distanceMeters: { type: Number },
        verifiedAt: { type: Date }
      },
      wifiIndoor: {
        verified: { type: Boolean, default: false },
        detectedBSSID: { type: String, default: '' },
        detectedSSID: { type: String, default: '' },
        detectedRssi: { type: Number },
        resolvedBuilding: { type: String, default: '' },
        resolvedFloor: { type: String, default: '' },
        resolvedRoom: { type: String, default: '' },
        isDemoMode: { type: Boolean, default: false },
        verifiedAt: { type: Date }
      },
      classroomMatch: {
        verified: { type: Boolean, default: false },
        scheduledRoom: { type: String, default: '' },
        resolvedRoom: { type: String, default: '' }
      }
    },
    teacherRemark: {
      type: String,
      default: ''
    }
  },
  { timestamps: true }
);

// Enforce Duplicate Attendance Prevention at database schema level
attendanceSchema.index({ student: 1, session: 1 }, { unique: true });

module.exports = mongoose.model('Attendance', attendanceSchema);
