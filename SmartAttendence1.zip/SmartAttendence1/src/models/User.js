const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Please provide a name'],
      trim: true,
      maxlength: [50, 'Name cannot exceed 50 characters']
    },
    email: {
      type: String,
      required: [true, 'Please provide an email address'],
      unique: true,
      lowercase: true,
      trim: true,
      match: [
        /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,})+$/,
        'Please provide a valid email address'
      ]
    },
    password: {
      type: String,
      required: [true, 'Please provide a password'],
      minlength: [6, 'Password must be at least 6 characters long'],
      select: false // Never return password field by default
    },
    role: {
      type: String,
      enum: {
        values: ['student', 'teacher', 'admin'],
        message: '{VALUE} is not a valid role. Allowed: student, teacher, admin'
      },
      default: 'student',
      required: true
    },
    // Student-specific fields
    rollNumber: {
      type: String,
      trim: true,
      uppercase: true,
      sparse: true // Allows null/undefined for teachers & admins while enforcing uniqueness for students
    },
    department: {
      type: String,
      trim: true
    },
    batch: {
      type: String,
      trim: true
    },
    qrCodeToken: {
      type: String,
      sparse: true
    },
    isFaceRegistered: {
      type: Boolean,
      default: false
    },
    faceDescriptor: {
      type: [Number],
      default: [],
      select: false // Large biometric vector kept private
    },

    // Teacher & Admin-specific fields
    employeeId: {
      type: String,
      trim: true,
      sparse: true
    },

    isActive: {
      type: Boolean,
      default: true
    }
  },
  {
    timestamps: true
  }
);

// Hash password prior to saving
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) {
    return next();
  }
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// Compare password helper
userSchema.methods.comparePassword = async function (candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

// Safe JSON serialization (strip sensitive internals)
userSchema.methods.toSafeObject = function () {
  const obj = this.toObject();
  delete obj.password;
  delete obj.faceDescriptor;
  return obj;
};

module.exports = mongoose.model('User', userSchema);
