const mongoose = require('mongoose');

const accessPointSchema = new mongoose.Schema(
  {
    bssid: {
      type: String,
      required: [true, 'Please provide BSSID (MAC Address)'],
      unique: true,
      uppercase: true,
      trim: true // e.g. "00:14:22:01:23:45"
    },
    ssid: {
      type: String,
      required: [true, 'Please provide SSID (Network Name)'],
      trim: true // e.g. "CAMPUS_ENG_WIFI"
    },
    building: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Building',
      required: true
    },
    floor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Floor',
      required: true
    },
    classroom: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Classroom',
      required: true
    },
    frequency: {
      type: String,
      default: '5 GHz'
    },
    minRssiThreshold: {
      type: Number,
      default: -85 // in dBm, values closer to 0 indicate stronger signal
    },
    isActive: {
      type: Boolean,
      default: true
    },
    description: {
      type: String,
      default: ''
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model('AccessPoint', accessPointSchema);
