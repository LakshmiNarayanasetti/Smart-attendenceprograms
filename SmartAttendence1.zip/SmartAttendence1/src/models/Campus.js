const mongoose = require('mongoose');

const campusSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Please provide a campus name'],
      trim: true,
      default: 'Main Engineering Campus'
    },
    code: {
      type: String,
      required: true,
      unique: true,
      uppercase: true,
      trim: true,
      default: 'CAMPUS-MAIN'
    },
    // GPS Geofence boundary center (Latitude & Longitude)
    // GPS is strictly for college campus verification - NEVER for floor detection!
    latitude: {
      type: Number,
      required: [true, 'Please provide campus latitude'],
      default: 12.971598 // Default college demo campus coordinates
    },
    longitude: {
      type: Number,
      required: [true, 'Please provide campus longitude'],
      default: 77.594562 // Default college demo campus coordinates
    },
    radiusMeters: {
      type: Number,
      required: true,
      default: 600, // 600 meters campus perimeter
      min: [50, 'Radius must be at least 50 meters']
    },
    address: {
      type: String,
      default: 'College Campus Road, Knowledge Park'
    },
    isActive: {
      type: Boolean,
      default: true
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Campus', campusSchema);
