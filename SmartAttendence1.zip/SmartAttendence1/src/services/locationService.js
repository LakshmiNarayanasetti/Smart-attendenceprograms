const Campus = require('../models/Campus');
const AccessPoint = require('../models/AccessPoint');
const Classroom = require('../models/Classroom');
const Building = require('../models/Building');
const Floor = require('../models/Floor');

/**
 * Calculate great-circle distance between two GPS coordinates using the Haversine formula
 * @param {number} lat1 Latitude of point 1
 * @param {number} lon1 Longitude of point 1
 * @param {number} lat2 Latitude of point 2
 * @param {number} lon2 Longitude of point 2
 * @returns {number} Distance in meters
 */
function calculateHaversineDistance(lat1, lon1, lat2, lon2) {
  const R = 6371e3; // Earth's radius in meters
  const phi1 = (lat1 * Math.PI) / 180;
  const phi2 = (lat2 * Math.PI) / 180;
  const deltaPhi = ((lat2 - lat1) * Math.PI) / 180;
  const deltaLambda = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(deltaPhi / 2) * Math.sin(deltaPhi / 2) +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(deltaLambda / 2) * Math.sin(deltaLambda / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return Math.round(R * c); // Distance in meters
}

/**
 * Verify if GPS coordinates fall within the College Campus boundary
 * NOTE: GPS is strictly for campus perimeter verification. Normal GPS cannot and should never claim to detect exact floors.
 */
async function verifyCampusGps(latitude, longitude, campusId = null) {
  if (typeof latitude !== 'number' || typeof longitude !== 'number') {
    return {
      valid: false,
      message: 'Invalid GPS coordinates provided.'
    };
  }

  let campus;
  if (campusId) {
    campus = await Campus.findById(campusId);
  } else {
    campus = await Campus.findOne({ isActive: true });
  }

  if (!campus) {
    return {
      valid: false,
      message: 'Active college campus geofence configuration not found.'
    };
  }

  const distanceMeters = calculateHaversineDistance(
    latitude,
    longitude,
    campus.latitude,
    campus.longitude
  );

  const isWithinCampus = distanceMeters <= campus.radiusMeters;

  return {
    valid: isWithinCampus,
    distanceMeters,
    allowedRadiusMeters: campus.radiusMeters,
    campusName: campus.name,
    message: isWithinCampus
      ? `Student GPS location is within ${campus.name} (Distance: ${distanceMeters}m / Max: ${campus.radiusMeters}m).`
      : `Student GPS location is outside the college campus boundary (Distance: ${distanceMeters}m exceeds permitted radius of ${campus.radiusMeters}m).`
  };
}

/**
 * Wi-Fi Indoor Positioning: Resolves Building -> Floor -> Room
 * Matches scanned Wi-Fi BSSID/RSSI against the registered AccessPoint mapping.
 * @param {Array|Object} scanData Array of { bssid, rssi, ssid } or single scan object
 */
async function resolveIndoorPosition(scanData) {
  if (!scanData) {
    return {
      success: false,
      message: 'No Wi-Fi scan data provided for indoor positioning.'
    };
  }

  const scans = Array.isArray(scanData) ? scanData : [scanData];
  if (scans.length === 0) {
    return {
      success: false,
      message: 'Empty Wi-Fi scan results.'
    };
  }

  // Normalize BSSIDs to uppercase and sort by RSSI (strongest signal first)
  const normalizedScans = scans
    .filter((s) => s && s.bssid)
    .map((s) => ({
      bssid: s.bssid.trim().toUpperCase(),
      ssid: s.ssid ? s.ssid.trim() : 'Unknown Network',
      rssi: typeof s.rssi === 'number' ? s.rssi : -70
    }))
    .sort((a, b) => b.rssi - a.rssi);

  if (normalizedScans.length === 0) {
    return {
      success: false,
      message: 'No valid BSSID MAC addresses found in scan data.'
    };
  }

  // Iterate over detected APs starting from the strongest signal
  for (const scan of normalizedScans) {
    const ap = await AccessPoint.findOne({
      bssid: scan.bssid,
      isActive: true
    })
      .populate('building')
      .populate('floor')
      .populate('classroom');

    if (ap && ap.building && ap.floor && ap.classroom) {
      // Check if signal meets minimum threshold (e.g. >= -85 dBm)
      if (ap.minRssiThreshold && scan.rssi < ap.minRssiThreshold) {
        continue; // Signal too weak to guarantee room presence, evaluate next AP
      }

      return {
        success: true,
        detectedBSSID: ap.bssid,
        detectedSSID: ap.ssid,
        detectedRssi: scan.rssi,
        building: {
          id: ap.building._id,
          name: ap.building.name,
          code: ap.building.code
        },
        floor: {
          id: ap.floor._id,
          floorNumber: ap.floor.floorNumber,
          floorName: ap.floor.floorName
        },
        classroom: {
          id: ap.classroom._id,
          roomNumber: ap.classroom.roomNumber,
          name: ap.classroom.name
        },
        confidence: scan.rssi > -65 ? 'High' : 'Medium'
      };
    }
  }

  return {
    success: false,
    message: 'None of the detected Wi-Fi Access Points match recognized campus indoor positioning zones.'
  };
}

/**
 * Verify whether the resolved indoor room matches the class session's designated classroom
 */
function verifyClassroomMatch(resolvedClassroomId, targetClassroomId) {
  if (!resolvedClassroomId || !targetClassroomId) {
    return false;
  }
  return resolvedClassroomId.toString() === targetClassroomId.toString();
}

module.exports = {
  calculateHaversineDistance,
  verifyCampusGps,
  resolveIndoorPosition,
  verifyClassroomMatch
};
