/**
 * Face Verification Service
 * Compares facial feature vectors (embeddings / descriptors) using Euclidean distance metric.
 */

function calculateEuclideanDistance(vec1, vec2) {
  if (!Array.isArray(vec1) || !Array.isArray(vec2) || vec1.length !== vec2.length) {
    throw new Error('Descriptors must be arrays of equal non-zero dimension.');
  }

  let sum = 0;
  for (let i = 0; i < vec1.length; i++) {
    const diff = vec1[i] - vec2[i];
    sum += diff * diff;
  }
  return Math.sqrt(sum);
}

/**
 * Verify probe face descriptor against the student's registered face descriptor
 * @param {Array<number>} probeDescriptor Captured during attendance check-in
 * @param {Array<number>} registeredDescriptor Stored in student's profile
 * @param {number} threshold Maximum allowable distance (default: 0.55)
 */
function verifyFace(probeDescriptor, registeredDescriptor, threshold = 0.55) {
  if (!probeDescriptor || !Array.isArray(probeDescriptor) || probeDescriptor.length === 0) {
    return {
      verified: false,
      distance: 1.0,
      confidenceScore: 0,
      message: 'No facial descriptor captured from camera stream.'
    };
  }

  if (!registeredDescriptor || !Array.isArray(registeredDescriptor) || registeredDescriptor.length === 0) {
    return {
      verified: false,
      distance: 1.0,
      confidenceScore: 0,
      message: 'Student has not registered their face descriptor yet. Please register your face profile first.'
    };
  }

  try {
    const distance = calculateEuclideanDistance(probeDescriptor, registeredDescriptor);
    const verified = distance <= threshold;
    const confidenceScore = Math.max(0, Math.min(100, Math.round((1 - distance) * 100)));

    return {
      verified,
      distance: Number(distance.toFixed(4)),
      confidenceScore,
      message: verified
        ? `Face verified successfully with ${confidenceScore}% biometric confidence (Euclidean distance: ${distance.toFixed(4)}).`
        : `Face verification failed. Biometric distance (${distance.toFixed(4)}) exceeded allowable match threshold.`
    };
  } catch (err) {
    return {
      verified: false,
      distance: 1.0,
      confidenceScore: 0,
      message: `Biometric calculation error: ${err.message}`
    };
  }
}

module.exports = {
  calculateEuclideanDistance,
  verifyFace
};
