const QRCode = require('qrcode');

/**
 * Generate Base64 Data URL for a QR code string
 * @param {string} payload Text or JSON string to encode
 * @returns {Promise<string>} Base64 image data URL
 */
async function generateQrDataUrl(payload) {
  if (!payload) {
    throw new Error('Payload is required to generate QR code.');
  }

  try {
    const dataUrl = await QRCode.toDataURL(payload, {
      errorCorrectionLevel: 'H',
      margin: 2,
      width: 300,
      color: {
        dark: '#0f172a',
        light: '#ffffff'
      }
    });
    return dataUrl;
  } catch (error) {
    throw new Error(`Failed to generate QR code: ${error.message}`);
  }
}

/**
 * Build a safe, non-sensitive QR payload for a student
 * Contains only public identification attributes (ID, Roll Number, Token)
 * NEVER contains passwords, hashes, or secrets.
 */
function createStudentSafeQrPayload(student) {
  return JSON.stringify({
    type: 'STUDENT_ID_CARD',
    studentId: student._id.toString(),
    rollNumber: student.rollNumber,
    qrToken: student.qrCodeToken || `QR_${student._id}`
  });
}

/**
 * Safely parse scanned QR data (supports JSON payload or raw token string)
 */
function parseScannedQrData(scannedData) {
  if (!scannedData || typeof scannedData !== 'string') {
    return null;
  }

  const trimmed = scannedData.trim();

  // Try parsing as JSON first
  try {
    const parsed = JSON.parse(trimmed);
    if (parsed && typeof parsed === 'object') {
      return {
        isJson: true,
        type: parsed.type || 'UNKNOWN',
        studentId: parsed.studentId || null,
        rollNumber: parsed.rollNumber || null,
        qrToken: parsed.qrToken || parsed.token || null,
        raw: trimmed
      };
    }
  } catch (e) {
    // Not JSON, treat as raw token or roll number
  }

  return {
    isJson: false,
    type: 'RAW_TOKEN',
    qrToken: trimmed,
    studentId: null,
    rollNumber: trimmed,
    raw: trimmed
  };
}

/**
 * Validate that the scanned QR token matches the student's unique ID token
 */
function verifyStudentQrToken(scannedToken, studentToken) {
  if (!scannedToken || !studentToken) {
    return false;
  }
  const parsed = parseScannedQrData(scannedToken);
  if (parsed.qrToken && parsed.qrToken === studentToken) {
    return true;
  }
  return scannedToken.trim() === studentToken.trim();
}

/**
 * Validate that the scanned QR token matches the active class session token
 */
function verifySessionQrToken(scannedToken, sessionQrToken) {
  if (!scannedToken || !sessionQrToken) {
    return false;
  }
  const parsed = parseScannedQrData(scannedToken);
  if (parsed.qrToken && parsed.qrToken === sessionQrToken) {
    return true;
  }
  return scannedToken.trim() === sessionQrToken.trim();
}

module.exports = {
  generateQrDataUrl,
  createStudentSafeQrPayload,
  parseScannedQrData,
  verifyStudentQrToken,
  verifySessionQrToken
};
