const User = require('../models/User');
const Campus = require('../models/Campus');
const Building = require('../models/Building');
const Floor = require('../models/Floor');
const Classroom = require('../models/Classroom');
const AccessPoint = require('../models/AccessPoint');
const Subject = require('../models/Subject');
const ClassSession = require('../models/ClassSession');

/**
 * Generates a realistic normalized 128-dimensional facial biometric descriptor
 */
function createSyntheticFaceDescriptor(seed = 1) {
  const descriptor = [];
  let sumSq = 0;
  for (let i = 0; i < 128; i++) {
    const val = Math.sin(seed + i * 0.1) * 0.5;
    descriptor.push(val);
    sumSq += val * val;
  }
  const norm = Math.sqrt(sumSq);
  return descriptor.map((v) => Number((v / norm).toFixed(5)));
}

const seedInitialData = async () => {
  try {
    // 1. Seed Admin
    const adminEmail = (process.env.DEFAULT_ADMIN_EMAIL || 'admin@college.edu').toLowerCase();
    let admin = await User.findOne({ email: adminEmail });
    if (!admin) {
      admin = await User.create({
        name: 'System Administrator',
        email: adminEmail,
        password: process.env.DEFAULT_ADMIN_PASSWORD || 'Admin@12345',
        role: 'admin',
        employeeId: 'ADM-001',
        department: 'Administration'
      });
      console.log(`[Seeder] Seeded Admin: ${adminEmail}`);
    }

    // 2. Seed Teacher
    const teacherEmail = (process.env.DEFAULT_TEACHER_EMAIL || 'teacher@college.edu').toLowerCase();
    let teacher = await User.findOne({ email: teacherEmail });
    if (!teacher) {
      teacher = await User.create({
        name: 'Prof. Sharma',
        email: teacherEmail,
        password: process.env.DEFAULT_TEACHER_PASSWORD || 'Teacher@12345',
        role: 'teacher',
        employeeId: 'FAC-101',
        department: 'Computer Science & Engineering'
      });
      console.log(`[Seeder] Seeded Teacher: ${teacherEmail}`);
    }

    // 3. Seed Sample Student with Registered Face Biometrics
    const studentEmail = 'student@college.edu';
    let student = await User.findOne({ email: studentEmail });
    if (!student) {
      const studentFaceDescriptor = createSyntheticFaceDescriptor(42);
      student = await User.create({
        name: 'Aarav Sharma',
        email: studentEmail,
        password: 'Student@12345',
        role: 'student',
        rollNumber: 'CS2026-001',
        department: 'Computer Science & Engineering',
        batch: '2024-2028',
        qrCodeToken: 'STU_QR_CS2026_001',
        isFaceRegistered: true,
        faceDescriptor: studentFaceDescriptor
      });
      console.log(`[Seeder] Seeded Student with Face Biometrics: ${studentEmail}`);
    }

    // 4. Seed Campus GPS Geofence
    let campus = await Campus.findOne();
    if (!campus) {
      campus = await Campus.create({
        name: 'Apex Institute of Technology Campus',
        code: 'CAMPUS-MAIN',
        latitude: 12.971598, // Demo college campus latitude
        longitude: 77.594562, // Demo college campus longitude
        radiusMeters: 600, // 600m college perimeter
        address: 'Knowledge Park, Academic Zone'
      });
      console.log(`[Seeder] Seeded Campus Geofence: ${campus.name} (Radius: ${campus.radiusMeters}m)`);
    }

    // 5. Seed Buildings
    let blockA = await Building.findOne({ code: 'ENG-A' });
    if (!blockA) {
      blockA = await Building.create({
        name: 'Aryabhata Engineering Block A',
        code: 'ENG-A',
        campus: campus._id,
        totalFloors: 4,
        description: 'Computer Science & Engineering Complex'
      });
    }

    let blockB = await Building.findOne({ code: 'SCI-B' });
    if (!blockB) {
      blockB = await Building.create({
        name: 'Ramanujan Science Block B',
        code: 'SCI-B',
        campus: campus._id,
        totalFloors: 3,
        description: 'Applied Sciences & Basic Engineering'
      });
    }

    // 6. Seed Floors
    let floorGroundA = await Floor.findOne({ building: blockA._id, floorNumber: 0 });
    if (!floorGroundA) {
      floorGroundA = await Floor.create({
        building: blockA._id,
        floorNumber: 0,
        floorName: 'Ground Floor'
      });
    }

    let floor1A = await Floor.findOne({ building: blockA._id, floorNumber: 1 });
    if (!floor1A) {
      floor1A = await Floor.create({
        building: blockA._id,
        floorNumber: 1,
        floorName: '1st Floor'
      });
    }

    let floor2A = await Floor.findOne({ building: blockA._id, floorNumber: 2 });
    if (!floor2A) {
      floor2A = await Floor.create({
        building: blockA._id,
        floorNumber: 2,
        floorName: '2nd Floor'
      });
    }

    let floor1B = await Floor.findOne({ building: blockB._id, floorNumber: 1 });
    if (!floor1B) {
      floor1B = await Floor.create({
        building: blockB._id,
        floorNumber: 1,
        floorName: '1st Floor'
      });
    }

    // 7. Seed Classrooms
    let room101 = await Classroom.findOne({ building: blockA._id, roomNumber: '101' });
    if (!room101) {
      room101 = await Classroom.create({
        roomNumber: '101',
        name: 'Room 101 - Advanced CS Lab',
        building: blockA._id,
        floor: floor1A._id,
        capacity: 60,
        type: 'Computer Lab'
      });
    }

    let room201 = await Classroom.findOne({ building: blockA._id, roomNumber: '201' });
    if (!room201) {
      room201 = await Classroom.create({
        roomNumber: '201',
        name: 'Room 201 - Main Lecture Hall A',
        building: blockA._id,
        floor: floor2A._id,
        capacity: 80,
        type: 'Lecture Hall'
      });
    }

    let room102B = await Classroom.findOne({ building: blockB._id, roomNumber: '102' });
    if (!room102B) {
      room102B = await Classroom.create({
        roomNumber: '102',
        name: 'Room 102 - Electronics Lab',
        building: blockB._id,
        floor: floor1B._id,
        capacity: 50,
        type: 'Classroom'
      });
    }

    // 8. Seed Wi-Fi Access Points for Indoor Positioning (Building -> Floor -> Room)
    const apList = [
      {
        bssid: '00:1A:2B:3C:4D:01',
        ssid: 'CAMPUS-CS-LAB-101',
        building: blockA._id,
        floor: floor1A._id,
        classroom: room101._id,
        frequency: '5 GHz',
        minRssiThreshold: -80,
        description: 'AP mounted at ceiling of Room 101 CS Lab'
      },
      {
        bssid: '00:1A:2B:3C:4D:02',
        ssid: 'CAMPUS-LECTURE-201',
        building: blockA._id,
        floor: floor2A._id,
        classroom: room201._id,
        frequency: '5 GHz',
        minRssiThreshold: -80,
        description: 'AP mounted at Room 201 Lecture Hall'
      },
      {
        bssid: '00:1A:2B:3C:4D:03',
        ssid: 'CAMPUS-ELEC-LAB-102',
        building: blockB._id,
        floor: floor1B._id,
        classroom: room102B._id,
        frequency: '2.4 GHz',
        minRssiThreshold: -85,
        description: 'AP mounted at Room 102 Science Block'
      }
    ];

    for (const apData of apList) {
      const existingAp = await AccessPoint.findOne({ bssid: apData.bssid });
      if (!existingAp) {
        await AccessPoint.create(apData);
      }
    }

    // 9. Seed Subjects
    let subjectDS = await Subject.findOne({ code: 'CS301' });
    if (!subjectDS) {
      subjectDS = await Subject.create({
        name: 'Data Structures & Algorithms',
        code: 'CS301',
        department: 'Computer Science & Engineering',
        semester: 3,
        assignedTeacher: teacher._id,
        description: 'Core concepts of Stacks, Queues, Trees, Graphs, and Hash Tables.'
      });
    }

    let subjectCN = await Subject.findOne({ code: 'CS302' });
    if (!subjectCN) {
      subjectCN = await Subject.create({
        name: 'Computer Networks',
        code: 'CS302',
        department: 'Computer Science & Engineering',
        semester: 4,
        assignedTeacher: teacher._id,
        description: 'OSI Model, TCP/IP, Routing Protocols, and Wi-Fi Positioning architectures.'
      });
    }

    // 10. Seed Active ClassSession (Ready for immediate demonstration)
    let activeSession = await ClassSession.findOne({ sessionCode: 'SES-CS301-DEMO' });
    if (!activeSession) {
      activeSession = await ClassSession.create({
        subject: subjectDS._id,
        teacher: teacher._id,
        classroom: room101._id,
        sessionCode: 'SES-CS301-DEMO',
        sessionQrToken: 'DEMO_SESSION_QR_TOKEN_CS301',
        startTime: new Date(),
        status: 'active',
        allowedRadiusMeters: 600
      });
      console.log(`[Seeder] Seeded Active Demo Class Session: SES-CS301-DEMO in Room 101`);
    }

    console.log('[Seeder] Campus infrastructure & sample entities seeded successfully.');
  } catch (error) {
    console.error('[Seeder Error]:', error.message);
  }
};

module.exports = seedInitialData;
