const crypto = require('crypto');
const ClassSession = require('../models/ClassSession');
const Subject = require('../models/Subject');
const Classroom = require('../models/Classroom');
const Attendance = require('../models/Attendance');
const { generateQrDataUrl } = require('../services/qrService');

/**
 * @desc    Get Teacher's Assigned Subjects and Available Classrooms
 * @route   GET /api/teacher/classes
 * @access  Private (Teacher)
 */
const getTeacherClasses = async (req, res) => {
  try {
    const teacherId = req.user.id;

    // Subjects assigned to this teacher or department
    const subjects = await Subject.find({
      $or: [{ assignedTeacher: teacherId }, { assignedTeacher: null }]
    });

    const classrooms = await Classroom.find()
      .populate('building')
      .populate('floor')
      .sort({ roomNumber: 1 });

    const activeSessions = await ClassSession.find({
      teacher: teacherId,
      status: 'active'
    })
      .populate('subject')
      .populate({
        path: 'classroom',
        populate: ['building', 'floor']
      });

    res.status(200).json({
      success: true,
      subjects,
      classrooms,
      activeSessions
    });
  } catch (error) {
    console.error('[Get Teacher Classes Error]:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve teacher class configurations.'
    });
  }
};

/**
 * @desc    Create / Start a Live Attendance Session
 * @route   POST /api/teacher/sessions
 * @access  Private (Teacher)
 */
const createAttendanceSession = async (req, res) => {
  try {
    const teacherId = req.user.id;
    const { subjectId, classroomId, allowedRadiusMeters } = req.body;

    if (!subjectId || !classroomId) {
      return res.status(400).json({
        success: false,
        message: 'Subject and Classroom are required to start an attendance session.'
      });
    }

    const subject = await Subject.findById(subjectId);
    if (!subject) {
      return res.status(404).json({ success: false, message: 'Subject not found.' });
    }

    const classroom = await Classroom.findById(classroomId)
      .populate('building')
      .populate('floor');
    if (!classroom) {
      return res.status(404).json({ success: false, message: 'Classroom not found.' });
    }

    // Generate unique session code and cryptographic QR token
    const sessionCode = `SES-${subject.code}-${Date.now().toString().slice(-4)}`;
    const sessionQrToken = `SESSION_${crypto.randomBytes(16).toString('hex')}`;

    const session = await ClassSession.create({
      subject: subjectId,
      teacher: teacherId,
      classroom: classroomId,
      sessionCode,
      sessionQrToken,
      startTime: new Date(),
      status: 'active',
      allowedRadiusMeters: allowedRadiusMeters || 600
    });

    // Generate QR Code data URL for the teacher's screen
    const qrDataUrl = await generateQrDataUrl(sessionQrToken);

    res.status(201).json({
      success: true,
      message: `Live attendance session started for ${subject.name} in ${classroom.name}.`,
      session: {
        _id: session._id,
        sessionCode: session.sessionCode,
        sessionQrToken: session.sessionQrToken,
        subject,
        classroom,
        startTime: session.startTime,
        status: session.status,
        qrDataUrl
      }
    });
  } catch (error) {
    console.error('[Create Session Error]:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create attendance session.'
    });
  }
};

/**
 * @desc    Get Details & Live QR for an Active Session
 * @route   GET /api/teacher/sessions/:id
 * @access  Private (Teacher)
 */
const getSessionDetails = async (req, res) => {
  try {
    const session = await ClassSession.findById(req.params.id)
      .populate('subject')
      .populate({
        path: 'classroom',
        populate: ['building', 'floor']
      });

    if (!session) {
      return res.status(404).json({ success: false, message: 'Session not found.' });
    }

    const qrDataUrl = await generateQrDataUrl(session.sessionQrToken);

    const attendances = await Attendance.find({ session: session._id })
      .populate('student', 'name rollNumber email department')
      .sort({ timestamp: -1 });

    res.status(200).json({
      success: true,
      session,
      qrDataUrl,
      attendanceCount: attendances.length,
      attendances
    });
  } catch (error) {
    console.error('[Get Session Details Error]:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve session details.'
    });
  }
};

/**
 * @desc    Close / Stop an Active Attendance Session
 * @route   PATCH /api/teacher/sessions/:id/close
 * @access  Private (Teacher)
 */
const closeAttendanceSession = async (req, res) => {
  try {
    const session = await ClassSession.findById(req.params.id);
    if (!session) {
      return res.status(404).json({ success: false, message: 'Session not found.' });
    }

    session.status = 'closed';
    session.endTime = new Date();
    await session.save();

    res.status(200).json({
      success: true,
      message: 'Attendance session closed successfully.',
      session
    });
  } catch (error) {
    console.error('[Close Session Error]:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to close attendance session.'
    });
  }
};

module.exports = {
  getTeacherClasses,
  createAttendanceSession,
  getSessionDetails,
  closeAttendanceSession
};
