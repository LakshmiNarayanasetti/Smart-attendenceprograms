const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const User = require('../models/User');

/**
 * Helper to generate signed JWT token
 */
const generateToken = (user) => {
  return jwt.sign(
    {
      id: user._id,
      role: user.role,
      email: user.email,
      name: user.name
    },
    process.env.JWT_SECRET || 'smart_attendance_super_secret_jwt_key_2026_secure',
    {
      expiresIn: process.env.JWT_EXPIRE || '24h'
    }
  );
};

/**
 * @desc    Register a new student
 * @route   POST /api/auth/register
 * @access  Public
 */
const registerStudent = async (req, res) => {
  try {
    const { name, email, password, rollNumber, department, batch } = req.body;

    // Basic validations
    if (!name || !email || !password || !rollNumber) {
      return res.status(400).json({
        success: false,
        message: 'Name, email, password, and roll number are required.'
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long.'
      });
    }

    // Check existing email
    const existingEmail = await User.findOne({ email: email.toLowerCase().trim() });
    if (existingEmail) {
      return res.status(400).json({
        success: false,
        message: 'An account with this email address already exists.'
      });
    }

    // Check existing roll number
    const existingRoll = await User.findOne({ rollNumber: rollNumber.toUpperCase().trim() });
    if (existingRoll) {
      return res.status(400).json({
        success: false,
        message: 'A student with this roll number is already registered.'
      });
    }

    // Generate unique secure token for student's QR/Barcode identification
    const qrCodeToken = `QR_${crypto.randomBytes(16).toString('hex')}`;

    // Create student account (Role is strictly locked to 'student')
    const student = await User.create({
      name: name.trim(),
      email: email.toLowerCase().trim(),
      password,
      role: 'student',
      rollNumber: rollNumber.toUpperCase().trim(),
      department: department ? department.trim() : 'General',
      batch: batch ? batch.trim() : new Date().getFullYear().toString(),
      qrCodeToken
    });

    const token = generateToken(student);

    res.status(201).json({
      success: true,
      message: 'Student registration successful.',
      token,
      user: student.toSafeObject()
    });
  } catch (error) {
    console.error('[Register Error]:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error during registration.'
    });
  }
};

/**
 * @desc    Unified Login (Student, Teacher, Admin)
 * @route   POST /api/auth/login
 * @access  Public
 */
const login = async (req, res) => {
  try {
    const { email, password, role } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide both email and password.'
      });
    }

    // Find user by email and explicitly include the hidden password field
    const user = await User.findOne({ email: email.toLowerCase().trim() }).select('+password');

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials.'
      });
    }

    // Check password
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials.'
      });
    }

    // If a specific role was requested from the UI login form, ensure role matches
    if (role && user.role !== role.toLowerCase()) {
      return res.status(403).json({
        success: false,
        message: `Account found, but it is registered as '${user.role}', not '${role}'. Please switch to the correct login tab.`
      });
    }

    if (!user.isActive) {
      return res.status(403).json({
        success: false,
        message: 'Your account has been deactivated. Please contact administration.'
      });
    }

    const token = generateToken(user);

    res.status(200).json({
      success: true,
      message: `Login successful as ${user.role}.`,
      token,
      user: user.toSafeObject()
    });
  } catch (error) {
    console.error('[Login Error]:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error during login.'
    });
  }
};

/**
 * @desc    Get Current Logged-in User Profile
 * @route   GET /api/auth/me
 * @access  Private
 */
const getMe = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found.'
      });
    }

    res.status(200).json({
      success: true,
      user: user.toSafeObject()
    });
  } catch (error) {
    console.error('[GetMe Error]:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error fetching profile.'
    });
  }
};

module.exports = {
  registerStudent,
  login,
  getMe
};
