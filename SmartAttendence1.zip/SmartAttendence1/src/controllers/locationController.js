const AccessPoint = require('../models/AccessPoint');
const Campus = require('../models/Campus');
const { verifyCampusGps, resolveIndoorPosition } = require('../services/locationService');

/**
 * @desc    Check GPS Campus Boundary
 * @route   POST /api/location/check-gps
 * @access  Private
 *
 * NOTE: GPS is only for checking whether the student is inside the college campus.
 * Normal GPS does NOT identify the exact floor.
 */
const checkCampusGps = async (req, res) => {
  try {
    const { latitude, longitude } = req.body;
    if (latitude === undefined || longitude === undefined) {
      return res.status(400).json({
        success: false,
        message: 'Latitude and Longitude are required.'
      });
    }

    const result = await verifyCampusGps(Number(latitude), Number(longitude));
    res.status(200).json({
      success: true,
      inCampus: result.valid,
      distanceMeters: result.distanceMeters,
      allowedRadiusMeters: result.allowedRadiusMeters,
      campusName: result.campusName,
      message: result.message
    });
  } catch (error) {
    console.error('[Check GPS Error]:', error);
    res.status(500).json({ success: false, message: 'Failed to verify GPS location.' });
  }
};

/**
 * @desc    Resolve Indoor Location via Wi-Fi Scan (Building -> Floor -> Room)
 * @route   POST /api/location/resolve-wifi
 * @access  Private
 */
const resolveWifi = async (req, res) => {
  try {
    const { scanData } = req.body;
    if (!scanData) {
      return res.status(400).json({
        success: false,
        message: 'Wi-Fi scan data (BSSID, RSSI, SSID) is required.'
      });
    }

    const resolution = await resolveIndoorPosition(scanData);
    if (!resolution.success) {
      return res.status(404).json({
        success: false,
        message: resolution.message
      });
    }

    res.status(200).json({
      success: true,
      location: resolution
    });
  } catch (error) {
    console.error('[Resolve Wi-Fi Error]:', error);
    res.status(500).json({ success: false, message: 'Failed to resolve indoor position.' });
  }
};

/**
 * @desc    Get List of Mapped Wi-Fi Access Points for Demo Wi-Fi Mode
 * @route   GET /api/location/demo-aps
 * @access  Public / Private
 *
 * Clearly designated for DEMO WIFI MODE during web browser testing / viva demonstration.
 */
const getDemoAccessPoints = async (req, res) => {
  try {
    const aps = await AccessPoint.find({ isActive: true })
      .populate('building', 'name code')
      .populate('floor', 'floorNumber floorName')
      .populate('classroom', 'roomNumber name type');

    res.status(200).json({
      success: true,
      mode: 'DEMO_WIFI_MODE',
      description: 'Pre-registered campus Access Points for indoor positioning simulation in web browsers.',
      accessPoints: aps
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

/**
 * @desc    Native Android Wi-Fi Scan Ingestion
 * @route   POST /api/location/wifi-scan
 * @access  Private (Bearer JWT)
 *
 * Used by the Android companion app to upload real OS-scanned Wi-Fi access points.
 */
const ingestAndroidScan = async (req, res) => {
  try {
    const { scans, deviceModel, timestamp } = req.body;

    if (!scans || !Array.isArray(scans)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid scan payload from Android scanner.'
      });
    }

    const resolution = await resolveIndoorPosition(scans);

    res.status(200).json({
      success: true,
      source: 'ANDROID_NATIVE_SCANNER',
      deviceModel: deviceModel || 'Android Device',
      scannedAt: timestamp || new Date(),
      detectedCount: scans.length,
      resolution
    });
  } catch (error) {
    console.error('[Android Scan Error]:', error);
    res.status(500).json({ success: false, message: 'Failed to process Android Wi-Fi scan.' });
  }
};

module.exports = {
  checkCampusGps,
  resolveWifi,
  getDemoAccessPoints,
  ingestAndroidScan
};
