const mongoose = require('mongoose');
const Attendance = require('../models/Attendance');
const ClassSession = require('../models/ClassSession');
const Subject = require('../models/Subject');
const Classroom = require('../models/Classroom');
const User = require('../models/User');

const { verifyCampusGps, resolveIndoorPosition, verifyClassroomMatch } = require('../services/locationService');
const { verifyFace } = require('../services/faceService');
const { verifySessionQrToken, verifyStudentQrToken, parseScannedQrData } = require('../services/qrService');

/**
 * @desc    Submit Complete Multi-Factor Attendance Verification
 * @route   POST /api/attendance/verify
 * @access  Private (Student)
 *
 * ATTENDANCE VERIFICATION FLOW:
 * 1. Auth check (Student)
 * 2. Session validity check
 * 3. Duplicate attendance prevention check
 * 4. QR/Barcode Token verification
 * 5. Biometric Face verification
 * 6. GPS Campus boundary verification (Campus perimeter only, NOT floor)
 * 7. Wi-Fi Indoor Positioning (Resolves Building -> Floor -> Room)
 * 8. Classroom cross-verification (Matches resolved Room with scheduled Session Room)
 * 9. Persistent record creation in MongoDB
 */
const submitAttendance = async (req, res) => {
  try {
    const studentId = req.user.id;
    const { sessionId, qrToken, faceDescriptor, gpsCoords, wifiScan, isDemoMode } = req.body;

    // 1. Validate required payload
    if (!sessionId) {
      return res.status(400).json({
        success: false,
        message: 'Class session ID is required.'
      });
    }

    const session = await ClassSession.findById(sessionId)
      .populate('subject')
      .populate({
        path: 'classroom',
        populate: ['building', 'floor']
      });

    if (!session) {
      return res.status(404).json({
        success: false,
        message: 'Active class session not found.'
      });
    }

    if (session.status !== 'active') {
      return res.status(400).json({
        success: false,
        message: 'This attendance session is closed by the instructor.'
      });
    }

    // 2. DUPLICATE ATTENDANCE PREVENTION
    const existingRecord = await Attendance.findOne({
      student: studentId,
      session: sessionId
    });

    if (existingRecord) {
      return res.status(409).json({
        success: false,
        message: 'Duplicate attendance rejected: Attendance has already been recorded for this session.',
        attendance: existingRecord
      });
    }

    const student = await User.findById(studentId).select('+password +faceDescriptor');

    // 3. QR/BARCODE VERIFICATION
    const isSessionQrValid = verifySessionQrToken(qrToken, session.sessionQrToken);
    const isStudentQrValid = verifyStudentQrToken(qrToken, student.qrCodeToken);

    if (!isSessionQrValid && !isStudentQrValid) {
      return res.status(400).json({
        success: false,
        stepFailed: 'QR_VERIFICATION',
        message: 'QR code verification failed. Scanned code does not match the active session QR code.'
      });
    }

    // 4. FACE RECOGNITION / VERIFICATION
    if (!student.isFaceRegistered || !student.faceDescriptor || student.faceDescriptor.length === 0) {
      return res.status(400).json({
        success: false,
        stepFailed: 'FACE_REGISTRATION_MISSING',
        message: 'You have not registered your face biometric profile yet. Please register your face in the profile section.'
      });
    }

    const faceCheck = verifyFace(faceDescriptor, student.faceDescriptor);
    if (!faceCheck.verified) {
      return res.status(403).json({
        success: false,
        stepFailed: 'FACE_VERIFICATION',
        message: faceCheck.message,
        confidenceScore: faceCheck.confidenceScore
      });
    }

    // 5. GPS CAMPUS BOUNDARY VERIFICATION
    // Important constraint: GPS only checks if student is inside the college campus perimeter. Never claims floor.
    if (!gpsCoords || typeof gpsCoords.latitude !== 'number' || typeof gpsCoords.longitude !== 'number') {
      return res.status(400).json({
        success: false,
        stepFailed: 'GPS_COORDINATES_MISSING',
        message: 'GPS coordinates must be provided for campus boundary check.'
      });
    }

    const gpsCheck = await verifyCampusGps(gpsCoords.latitude, gpsCoords.longitude);
    if (!gpsCheck.valid) {
      return res.status(403).json({
        success: false,
        stepFailed: 'GPS_CAMPUS_BOUNDARY',
        message: gpsCheck.message,
        distanceMeters: gpsCheck.distanceMeters,
        allowedRadiusMeters: gpsCheck.allowedRadiusMeters
      });
    }

    // 6. WI-FI BASED INDOOR POSITIONING (Building -> Floor -> Room)
    if (!wifiScan) {
      return res.status(400).json({
        success: false,
        stepFailed: 'WIFI_SCAN_MISSING',
        message: 'Wi-Fi scan data is required for indoor positioning.'
      });
    }

    const wifiResolution = await resolveIndoorPosition(wifiScan);
    if (!wifiResolution.success) {
      return res.status(403).json({
        success: false,
        stepFailed: 'WIFI_INDOOR_POSITIONING',
        message: `Indoor localization failed: ${wifiResolution.message}`
      });
    }

    // 7. CLASSROOM MATCH VERIFICATION
    const isRoomMatch = verifyClassroomMatch(
      wifiResolution.classroom.id,
      session.classroom._id
    );

    if (!isRoomMatch) {
      return res.status(403).json({
        success: false,
        stepFailed: 'CLASSROOM_MISMATCH',
        message: `Location mismatch: You are positioned at ${wifiResolution.building.name}, ${wifiResolution.floor.floorName}, ${wifiResolution.classroom.name}. This class is scheduled in ${session.classroom.building.name}, ${session.classroom.floor.floorName}, ${session.classroom.name}.`,
        detectedLocation: {
          building: wifiResolution.building.name,
          floor: wifiResolution.floor.floorName,
          room: wifiResolution.classroom.name
        },
        scheduledLocation: {
          building: session.classroom.building.name,
          floor: session.classroom.floor.floorName,
          room: session.classroom.name
        }
      });
    }

    // 8. RECORD VERIFIED ATTENDANCE IN MONGODB
    const attendance = await Attendance.create({
      student: studentId,
      session: session._id,
      subject: session.subject._id,
      classroom: session.classroom._id,
      timestamp: new Date(),
      status: 'Present',
      verificationSteps: {
        qrScanned: {
          verified: true,
          tokenValue: qrToken,
          verifiedAt: new Date()
        },
        faceRecognition: {
          verified: true,
          confidenceScore: faceCheck.confidenceScore,
          verifiedAt: new Date()
        },
        gpsCampus: {
          verified: true,
          latitude: gpsCoords.latitude,
          longitude: gpsCoords.longitude,
          distanceMeters: gpsCheck.distanceMeters,
          verifiedAt: new Date()
        },
        wifiIndoor: {
          verified: true,
          detectedBSSID: wifiResolution.detectedBSSID,
          detectedSSID: wifiResolution.detectedSSID,
          detectedRssi: wifiResolution.detectedRssi,
          resolvedBuilding: wifiResolution.building.name,
          resolvedFloor: wifiResolution.floor.floorName,
          resolvedRoom: wifiResolution.classroom.name,
          isDemoMode: Boolean(isDemoMode),
          verifiedAt: new Date()
        },
        classroomMatch: {
          verified: true,
          scheduledRoom: session.classroom.name,
          resolvedRoom: wifiResolution.classroom.name
        }
      }
    });

    const populatedAttendance = await Attendance.findById(attendance._id)
      .populate('student', 'name rollNumber email department')
      .populate('subject', 'name code')
      .populate({
        path: 'classroom',
        populate: ['building', 'floor']
      });

    return res.status(201).json({
      success: true,
      message: 'Attendance verified and recorded successfully!',
      attendance: populatedAttendance
    });
  } catch (error) {
    console.error('[Attendance Verification Error]:', error);
    if (error.code === 11000) {
      return res.status(409).json({
        success: false,
        message: 'Duplicate attendance rejected: Record already exists for this session.'
      });
    }
    return res.status(500).json({
      success: false,
      message: error.message || 'Server error verifying attendance.'
    });
  }
};

/**
 * @desc    Get Current Student's Attendance History & Subject Percentages
 * @route   GET /api/attendance/my-history
 * @access  Private (Student)
 */
const getMyAttendanceHistory = async (req, res) => {
  try {
    const studentId = req.user.id;

    const records = await Attendance.find({ student: studentId })
      .populate('subject', 'name code department')
      .populate({
        path: 'classroom',
        populate: ['building', 'floor']
      })
      .populate('session', 'sessionCode date')
      .sort({ timestamp: -1 });

    // Aggregate subject-wise percentages
    const subjectStats = {};
    for (const record of records) {
      const subjectCode = record.subject ? record.subject.code : 'UNKNOWN';
      const subjectName = record.subject ? record.subject.name : 'Unknown Subject';

      if (!subjectStats[subjectCode]) {
        subjectStats[subjectCode] = {
          code: subjectCode,
          name: subjectName,
          totalPresent: 0,
          totalRecords: 0
        };
      }

      subjectStats[subjectCode].totalRecords += 1;
      if (record.status === 'Present' || record.status === 'Late') {
        subjectStats[subjectCode].totalPresent += 1;
      }
    }

    const subjectWiseReports = Object.values(subjectStats).map((stat) => ({
      code: stat.code,
      name: stat.name,
      totalPresent: stat.totalPresent,
      totalClasses: stat.totalRecords,
      percentage: stat.totalRecords > 0 ? Math.round((stat.totalPresent / stat.totalRecords) * 100) : 0
    }));

    const totalClasses = records.length;
    const totalPresent = records.filter((r) => r.status === 'Present' || r.status === 'Late').length;
    const overallPercentage = totalClasses > 0 ? Math.round((totalPresent / totalClasses) * 100) : 0;

    res.status(200).json({
      success: true,
      totalClasses,
      totalPresent,
      overallPercentage,
      subjectWiseReports,
      history: records
    });
  } catch (error) {
    console.error('[Get My History Error]:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve attendance history.'
    });
  }
};

/**
 * @desc    Get Real-Time Attendance for a Class Session (Teacher/Admin Monitor)
 * @route   GET /api/attendance/session/:sessionId
 * @access  Private (Teacher, Admin)
 */
const getSessionAttendance = async (req, res) => {
  try {
    const { sessionId } = req.params;

    const session = await ClassSession.findById(sessionId)
      .populate('subject')
      .populate({
        path: 'classroom',
        populate: ['building', 'floor']
      })
      .populate('teacher', 'name email');

    if (!session) {
      return res.status(404).json({
        success: false,
        message: 'Session not found.'
      });
    }

    const records = await Attendance.find({ session: sessionId })
      .populate('student', 'name rollNumber email department batch')
      .sort({ timestamp: -1 });

    res.status(200).json({
      success: true,
      session,
      totalCount: records.length,
      records
    });
  } catch (error) {
    console.error('[Get Session Attendance Error]:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve session attendance.'
    });
  }
};

/**
 * @desc    Update Attendance Record Status / Teacher Remark
 * @route   PATCH /api/attendance/:id
 * @access  Private (Teacher, Admin)
 */
const updateAttendanceStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status, teacherRemark } = req.body;

    const record = await Attendance.findById(id);
    if (!record) {
      return res.status(404).json({
        success: false,
        message: 'Attendance record not found.'
      });
    }

    if (status) record.status = status;
    if (teacherRemark !== undefined) record.teacherRemark = teacherRemark;

    await record.save();

    res.status(200).json({
      success: true,
      message: 'Attendance status updated successfully.',
      record
    });
  } catch (error) {
    console.error('[Update Attendance Status Error]:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update attendance status.'
    });
  }
};

/**
 * @desc    Generate Aggregated Attendance Reports (Student-wise, Class-wise, Subject-wise)
 * @route   GET /api/attendance/reports
 * @access  Private (Teacher, Admin)
 */
const getAttendanceReports = async (req, res) => {
  try {
    const { subjectId, classroomId, studentId } = req.query;
    const filter = {};

    if (subjectId) filter.subject = subjectId;
    if (classroomId) filter.classroom = classroomId;
    if (studentId) filter.student = studentId;

    const records = await Attendance.find(filter)
      .populate('student', 'name rollNumber department batch')
      .populate('subject', 'name code department')
      .populate({
        path: 'classroom',
        populate: ['building', 'floor']
      })
      .sort({ timestamp: -1 });

    // 1. Student-wise breakdown
    const studentMap = {};
    records.forEach((r) => {
      if (!r.student) return;
      const sId = r.student._id.toString();
      if (!studentMap[sId]) {
        studentMap[sId] = {
          student: r.student,
          totalPresent: 0,
          totalRecords: 0
        };
      }
      studentMap[sId].totalRecords += 1;
      if (r.status === 'Present' || r.status === 'Late') {
        studentMap[sId].totalPresent += 1;
      }
    });

    const studentReports = Object.values(studentMap).map((item) => ({
      student: item.student,
      totalClasses: item.totalRecords,
      totalPresent: item.totalPresent,
      percentage: Math.round((item.totalPresent / item.totalRecords) * 100)
    }));

    // 2. Subject-wise breakdown
    const subjectMap = {};
    records.forEach((r) => {
      if (!r.subject) return;
      const subId = r.subject._id.toString();
      if (!subjectMap[subId]) {
        subjectMap[subId] = {
          subject: r.subject,
          totalPresent: 0,
          totalRecords: 0
        };
      }
      subjectMap[subId].totalRecords += 1;
      if (r.status === 'Present' || r.status === 'Late') {
        subjectMap[subId].totalPresent += 1;
      }
    });

    const subjectReports = Object.values(subjectMap).map((item) => ({
      subject: item.subject,
      totalClasses: item.totalRecords,
      totalPresent: item.totalPresent,
      percentage: Math.round((item.totalPresent / item.totalRecords) * 100)
    }));

    res.status(200).json({
      success: true,
      totalRecords: records.length,
      studentReports,
      subjectReports,
      rawRecords: records
    });
  } catch (error) {
    console.error('[Attendance Reports Error]:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate attendance reports.'
    });
  }
};

/**
 * @desc    Verify Scanned Student Identification QR Code
 * @route   POST /api/attendance/scan-student-qr
 * @access  Private (Teacher, Student, Admin)
 */
const verifyStudentQrCode = async (req, res) => {
  try {
    const { qrData } = req.body;
    if (!qrData) {
      return res.status(400).json({
        success: false,
        verified: false,
        message: 'No QR code payload provided for scanning.'
      });
    }

    const parsed = parseScannedQrData(qrData);
    if (!parsed) {
      return res.status(400).json({
        success: false,
        verified: false,
        message: 'Malformed or empty QR code data.'
      });
    }

    // Build conditions to look up student in MongoDB
    const searchConditions = [];
    if (parsed.studentId && mongoose.Types.ObjectId.isValid(parsed.studentId)) {
      searchConditions.push({ _id: parsed.studentId });
    }
    if (parsed.qrToken) {
      searchConditions.push({ qrCodeToken: parsed.qrToken });
    }
    if (parsed.rollNumber) {
      searchConditions.push({ rollNumber: parsed.rollNumber.toUpperCase() });
    }
    searchConditions.push({ qrCodeToken: parsed.raw });
    searchConditions.push({ rollNumber: parsed.raw.toUpperCase() });

    const student = await User.findOne({
      $or: searchConditions,
      role: 'student'
    }).select('-password -faceDescriptor');

    if (!student) {
      return res.status(404).json({
        success: false,
        verified: false,
        message: 'Invalid or unknown QR code: Student was not found in the database.'
      });
    }

    if (!student.isActive) {
      return res.status(403).json({
        success: false,
        verified: false,
        message: `Student account for ${student.name} (${student.rollNumber}) is currently deactivated.`
      });
    }

    return res.status(200).json({
      success: true,
      verified: true,
      message: `Student identity verified: ${student.name} (${student.rollNumber})`,
      student: {
        _id: student._id,
        name: student.name,
        rollNumber: student.rollNumber,
        department: student.department || 'General',
        batch: student.batch || '2024-2028',
        qrCodeToken: student.qrCodeToken,
        isFaceRegistered: Boolean(student.isFaceRegistered),
        verifiedAt: new Date().toISOString()
      }
    });
  } catch (error) {
    console.error('[Scan Student QR Error]:', error);
    return res.status(500).json({
      success: false,
      verified: false,
      message: 'Server error processing student QR code.'
    });
  }
};

module.exports = {
  submitAttendance,
  getMyAttendanceHistory,
  getSessionAttendance,
  updateAttendanceStatus,
  getAttendanceReports,
  verifyStudentQrCode
};
