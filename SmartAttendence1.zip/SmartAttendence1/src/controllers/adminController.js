const User = require('../models/User');
const Campus = require('../models/Campus');
const Building = require('../models/Building');
const Floor = require('../models/Floor');
const Classroom = require('../models/Classroom');
const AccessPoint = require('../models/AccessPoint');
const Subject = require('../models/Subject');
const ClassSession = require('../models/ClassSession');
const Attendance = require('../models/Attendance');

/**
 * @desc    Get Overall System Analytics and Metrics
 * @route   GET /api/admin/stats
 * @access  Private (Admin)
 */
const getSystemStats = async (req, res) => {
  try {
    const totalStudents = await User.countDocuments({ role: 'student' });
    const totalTeachers = await User.countDocuments({ role: 'teacher' });
    const totalSubjects = await Subject.countDocuments();
    const totalRooms = await Classroom.countDocuments();
    const totalAPs = await AccessPoint.countDocuments({ isActive: true });
    const activeSessions = await ClassSession.countDocuments({ status: 'active' });

    // Today's attendance records
    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0);

    const todayAttendances = await Attendance.countDocuments({
      createdAt: { $gte: startOfToday }
    });

    const totalAttendances = await Attendance.countDocuments();

    res.status(200).json({
      success: true,
      stats: {
        totalStudents,
        totalTeachers,
        totalSubjects,
        totalRooms,
        totalAPs,
        activeSessions,
        todayAttendances,
        totalAttendances
      }
    });
  } catch (error) {
    console.error('[Admin Stats Error]:', error);
    res.status(500).json({ success: false, message: 'Failed to retrieve stats.' });
  }
};

/**
 * @desc    Get & Update Campus Geofence Configuration
 * @route   GET & PUT /api/admin/campus
 * @access  Private (Admin)
 */
const getCampusConfig = async (req, res) => {
  try {
    let campus = await Campus.findOne();
    if (!campus) {
      campus = await Campus.create({
        name: 'Main University Campus',
        code: 'CAMPUS-MAIN',
        latitude: 12.971598,
        longitude: 77.594562,
        radiusMeters: 600
      });
    }
    res.status(200).json({ success: true, campus });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const updateCampusConfig = async (req, res) => {
  try {
    const { name, latitude, longitude, radiusMeters, address } = req.body;
    let campus = await Campus.findOne();
    if (!campus) {
      campus = new Campus();
    }

    if (name) campus.name = name;
    if (latitude !== undefined) campus.latitude = Number(latitude);
    if (longitude !== undefined) campus.longitude = Number(longitude);
    if (radiusMeters !== undefined) campus.radiusMeters = Number(radiusMeters);
    if (address) campus.address = address;

    await campus.save();

    res.status(200).json({
      success: true,
      message: 'Campus GPS Geofence boundary updated successfully.',
      campus
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

/**
 * @desc    Get Entire Campus Infrastructure (Buildings, Floors, Classrooms)
 * @route   GET /api/admin/infrastructure
 * @access  Private (Admin, Teacher)
 */
const getInfrastructure = async (req, res) => {
  try {
    const buildings = await Building.find().populate('campus');
    const floors = await Floor.find().populate('building');
    const classrooms = await Classroom.find()
      .populate('building')
      .populate('floor');

    res.status(200).json({
      success: true,
      buildings,
      floors,
      classrooms
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

/**
 * @desc    Manage Buildings, Floors, Classrooms
 * @route   POST /api/admin/buildings | floors | classrooms
 * @access  Private (Admin)
 */
const createBuilding = async (req, res) => {
  try {
    const { name, code, totalFloors, description } = req.body;
    const campus = await Campus.findOne();

    const building = await Building.create({
      name,
      code: code.toUpperCase().trim(),
      campus: campus._id,
      totalFloors: totalFloors || 4,
      description
    });

    res.status(201).json({ success: true, building });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const createFloor = async (req, res) => {
  try {
    const { buildingId, floorNumber, floorName } = req.body;
    const floor = await Floor.create({
      building: buildingId,
      floorNumber: Number(floorNumber),
      floorName
    });
    res.status(201).json({ success: true, floor });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const createClassroom = async (req, res) => {
  try {
    const { buildingId, floorId, roomNumber, name, capacity, type } = req.body;
    const room = await Classroom.create({
      building: buildingId,
      floor: floorId,
      roomNumber,
      name,
      capacity: capacity || 60,
      type: type || 'Classroom'
    });
    res.status(201).json({ success: true, room });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

/**
 * @desc    Wi-Fi Access Points Management
 * @route   GET, POST, DELETE /api/admin/access-points
 * @access  Private (Admin)
 */
const getAccessPoints = async (req, res) => {
  try {
    const aps = await AccessPoint.find()
      .populate('building')
      .populate('floor')
      .populate('classroom')
      .sort({ createdAt: -1 });

    res.status(200).json({ success: true, accessPoints: aps });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const createAccessPoint = async (req, res) => {
  try {
    const { bssid, ssid, buildingId, floorId, classroomId, minRssiThreshold, frequency } = req.body;

    if (!bssid || !ssid || !buildingId || !floorId || !classroomId) {
      return res.status(400).json({
        success: false,
        message: 'BSSID, SSID, Building, Floor, and Classroom are required.'
      });
    }

    const ap = await AccessPoint.create({
      bssid: bssid.toUpperCase().trim(),
      ssid: ssid.trim(),
      building: buildingId,
      floor: floorId,
      classroom: classroomId,
      minRssiThreshold: minRssiThreshold || -85,
      frequency: frequency || '5 GHz'
    });

    const populated = await AccessPoint.findById(ap._id)
      .populate('building')
      .populate('floor')
      .populate('classroom');

    res.status(201).json({ success: true, accessPoint: populated });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ success: false, message: 'This BSSID is already registered.' });
    }
    res.status(500).json({ success: false, message: error.message });
  }
};

const deleteAccessPoint = async (req, res) => {
  try {
    await AccessPoint.findByIdAndDelete(req.params.id);
    res.status(200).json({ success: true, message: 'Access point removed.' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

/**
 * @desc    Curriculum / Subject Management
 * @route   GET & POST /api/admin/subjects
 * @access  Private (Admin)
 */
const getSubjects = async (req, res) => {
  try {
    const subjects = await Subject.find().populate('assignedTeacher', 'name email department');
    res.status(200).json({ success: true, subjects });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const createSubject = async (req, res) => {
  try {
    const { name, code, department, semester, assignedTeacher } = req.body;
    const subject = await Subject.create({
      name: name.trim(),
      code: code.toUpperCase().trim(),
      department: department.trim(),
      semester: Number(semester) || 1,
      assignedTeacher: assignedTeacher || null
    });
    res.status(201).json({ success: true, subject });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

/**
 * @desc    User Management (List & Create Teachers/Admins)
 * @route   GET & POST /api/admin/users
 * @access  Private (Admin)
 */
const getUsers = async (req, res) => {
  try {
    const { role } = req.query;
    const filter = role ? { role } : {};
    const users = await User.find(filter).select('-faceDescriptor').sort({ createdAt: -1 });
    res.status(200).json({ success: true, users });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const createUser = async (req, res) => {
  try {
    const { name, email, password, role, employeeId, department } = req.body;

    if (!name || !email || !password || !role) {
      return res.status(400).json({ success: false, message: 'All fields are required.' });
    }

    const user = await User.create({
      name: name.trim(),
      email: email.toLowerCase().trim(),
      password,
      role,
      employeeId,
      department
    });

    res.status(201).json({
      success: true,
      message: `${role} account created successfully.`,
      user: user.toSafeObject()
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  getSystemStats,
  getCampusConfig,
  updateCampusConfig,
  getInfrastructure,
  createBuilding,
  createFloor,
  createClassroom,
  getAccessPoints,
  createAccessPoint,
  deleteAccessPoint,
  getSubjects,
  createSubject,
  getUsers,
  createUser
};
