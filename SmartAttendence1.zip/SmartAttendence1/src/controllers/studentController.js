const User = require('../models/User');
const ClassSession = require('../models/ClassSession');
const { generateQrDataUrl, createStudentSafeQrPayload } = require('../services/qrService');

/**
 * @desc    Register or Update Face Biometric Descriptor
 * @route   POST /api/student/face-descriptor
 * @access  Private (Student)
 */
const registerFaceDescriptor = async (req, res) => {
  try {
    const studentId = req.user.id;
    const { descriptor } = req.body;

    if (!descriptor || !Array.isArray(descriptor) || descriptor.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'A valid facial descriptor array is required.'
      });
    }

    const student = await User.findById(studentId);
    if (!student) {
      return res.status(404).json({ success: false, message: 'Student account not found.' });
    }

    student.faceDescriptor = descriptor;
    student.isFaceRegistered = true;
    await student.save();

    res.status(200).json({
      success: true,
      message: 'Facial biometric descriptor registered successfully.',
      isFaceRegistered: true
    });
  } catch (error) {
    console.error('[Register Face Error]:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to save facial biometric descriptor.'
    });
  }
};

/**
 * @desc    Get Student's Personal Identification QR Code
 * @route   GET /api/student/my-qr
 * @access  Private (Student)
 */
const getMyQrCode = async (req, res) => {
  try {
    const student = await User.findById(req.user.id);
    if (!student) {
      return res.status(404).json({ success: false, message: 'Student not found.' });
    }

    // Ensure student has a persistent unique QR token
    if (!student.qrCodeToken) {
      student.qrCodeToken = `STU_QR_${student.rollNumber || student._id}`;
      await student.save();
    }

    // Safe payload containing only student ID, roll number, and public token
    const qrPayload = createStudentSafeQrPayload(student);
    const qrDataUrl = await generateQrDataUrl(qrPayload);

    res.status(200).json({
      success: true,
      qrToken: student.qrCodeToken,
      rollNumber: student.rollNumber,
      name: student.name,
      department: student.department || 'General',
      qrPayload,
      qrDataUrl
    });
  } catch (error) {
    console.error('[Get My QR Error]:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate student QR code.'
    });
  }
};

/**
 * @desc    Update Student Profile
 * @route   PATCH /api/student/profile
 * @access  Private (Student)
 */
const updateProfile = async (req, res) => {
  try {
    const studentId = req.user.id;
    const { name, department, batch } = req.body;

    const student = await User.findById(studentId);
    if (!student) {
      return res.status(404).json({ success: false, message: 'Student not found.' });
    }

    if (name) student.name = name.trim();
    if (department) student.department = department.trim();
    if (batch) student.batch = batch.trim();

    await student.save();

    res.status(200).json({
      success: true,
      message: 'Profile updated successfully.',
      user: student.toSafeObject()
    });
  } catch (error) {
    console.error('[Update Profile Error]:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update student profile.'
    });
  }
};

/**
 * @desc    List Active Class Attendance Sessions
 * @route   GET /api/student/active-sessions
 * @access  Private (Student)
 */
const getActiveSessions = async (req, res) => {
  try {
    const sessions = await ClassSession.find({ status: 'active' })
      .populate('subject')
      .populate({
        path: 'classroom',
        populate: ['building', 'floor']
      })
      .populate('teacher', 'name email department')
      .sort({ startTime: -1 });

    res.status(200).json({
      success: true,
      count: sessions.length,
      sessions
    });
  } catch (error) {
    console.error('[Get Active Sessions Error]:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve active sessions.'
    });
  }
};

module.exports = {
  registerFaceDescriptor,
  getMyQrCode,
  updateProfile,
  getActiveSessions
};
