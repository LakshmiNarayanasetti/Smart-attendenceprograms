/**
 * Stage 1 Automated Verification Script
 * Validates MongoDB connectivity, Seeding, Registration, Login, and Role-Based Access Control (RBAC).
 */

const http = require('http');

const PORT = process.env.PORT || 5000;
const BASE_URL = `http://localhost:${PORT}`;

function makeRequest(path, method = 'GET', body = null, token = null) {
  return new Promise((resolve, reject) => {
    const url = new URL(path, BASE_URL);
    const headers = {};

    if (body) {
      headers['Content-Type'] = 'application/json';
    }
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const req = http.request(
      url,
      {
        method,
        headers
      },
      (res) => {
        let rawData = '';
        res.on('data', (chunk) => {
          rawData += chunk;
        });
        res.on('end', () => {
          try {
            const parsed = JSON.parse(rawData);
            resolve({ statusCode: res.statusCode, headers: res.headers, body: parsed });
          } catch (e) {
            resolve({ statusCode: res.statusCode, headers: res.headers, raw: rawData });
          }
        });
      }
    );

    req.on('error', (e) => reject(e));

    if (body) {
      req.write(JSON.stringify(body));
    }
    req.end();
  });
}

async function runTests() {
  console.log('====================================================');
  console.log('   STARTING STAGE 1 VERIFICATION TESTS');
  console.log('====================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`  ✓ PASS: ${message}`);
      passed++;
    } else {
      console.error(`  ✗ FAIL: ${message}`);
      failed++;
    }
  }

  try {
    // 1. Health check
    console.log('[Test 1]: Checking API health and MongoDB connection...');
    const healthRes = await makeRequest('/api/health');
    assert(healthRes.statusCode === 200, 'Health endpoint returned 200 OK');
    assert(healthRes.body.database === 'connected', 'Database reports status "connected"');

    // 2. Admin Login (Seeded)
    console.log('\n[Test 2]: Testing Admin Login with default seeded account...');
    const adminLoginRes = await makeRequest('/api/auth/login', 'POST', {
      email: 'admin@college.edu',
      password: 'Admin@12345',
      role: 'admin'
    });
    assert(adminLoginRes.statusCode === 200, 'Admin login succeeded (200)');
    assert(Boolean(adminLoginRes.body.token), 'Admin JWT token received');
    assert(adminLoginRes.body.user.role === 'admin', 'User role is correctly identified as "admin"');
    assert(adminLoginRes.body.user.password === undefined, 'Password field is NOT exposed in response');
    const adminToken = adminLoginRes.body.token;

    // 3. Teacher Login (Seeded)
    console.log('\n[Test 3]: Testing Teacher Login with default seeded account...');
    const teacherLoginRes = await makeRequest('/api/auth/login', 'POST', {
      email: 'teacher@college.edu',
      password: 'Teacher@12345',
      role: 'teacher'
    });
    assert(teacherLoginRes.statusCode === 200, 'Teacher login succeeded (200)');
    assert(Boolean(teacherLoginRes.body.token), 'Teacher JWT token received');
    assert(teacherLoginRes.body.user.role === 'teacher', 'User role is correctly identified as "teacher"');
    assert(teacherLoginRes.body.user.password === undefined, 'Password field is NOT exposed in response');
    const teacherToken = teacherLoginRes.body.token;

    // 4. Student Registration
    console.log('\n[Test 4]: Testing Student Registration...');
    const testStudentRoll = `CS${Math.floor(1000 + Math.random() * 9000)}`;
    const testStudentEmail = `teststudent_${Date.now()}@college.edu`;
    const regRes = await makeRequest('/api/auth/register', 'POST', {
      name: 'Aarav Sharma',
      email: testStudentEmail,
      rollNumber: testStudentRoll,
      department: 'Computer Science',
      batch: '2024-2028',
      password: 'Password@123'
    });
    assert(regRes.statusCode === 201, 'Student registration created account (201)');
    assert(Boolean(regRes.body.token), 'Student JWT token received upon registration');
    assert(regRes.body.user.role === 'student', 'Registered role is strictly locked to "student"');
    assert(regRes.body.user.rollNumber === testStudentRoll, 'Roll number matches correctly');
    assert(regRes.body.user.password === undefined, 'Password is NOT exposed in response');
    const studentToken = regRes.body.token;

    // 5. Duplicate Email & Roll Number Prevention
    console.log('\n[Test 5]: Testing duplicate registration constraints...');
    const dupRes = await makeRequest('/api/auth/register', 'POST', {
      name: 'Duplicate Student',
      email: testStudentEmail,
      rollNumber: `NEW_${testStudentRoll}`,
      password: 'Password@123'
    });
    assert(dupRes.statusCode === 400, 'Duplicate email registration was rejected with 400 Bad Request');

    // 6. Student Login
    console.log('\n[Test 6]: Testing Student Login...');
    const studentLoginRes = await makeRequest('/api/auth/login', 'POST', {
      email: testStudentEmail,
      password: 'Password@123',
      role: 'student'
    });
    assert(studentLoginRes.statusCode === 200, 'Student login succeeded (200)');
    assert(studentLoginRes.body.user.email === testStudentEmail, 'Authenticated student email verified');

    // 7. Protected Route /api/auth/me Profile verification
    console.log('\n[Test 7]: Testing Protected Profile Route (/api/auth/me)...');
    const meRes = await makeRequest('/api/auth/me', 'GET', null, studentToken);
    assert(meRes.statusCode === 200, '/api/auth/me returned 200 with valid JWT');
    assert(meRes.body.user.rollNumber === testStudentRoll, 'Profile returned correct roll number');
    assert(meRes.body.user.password === undefined, 'Profile does NOT expose password');

    // 8. Role-Based Access Control (RBAC) Guard Tests
    console.log('\n[Test 8]: Testing Role-Based Access Control Guards...');
    // Student accessing student route -> should pass (200)
    const sToS = await makeRequest('/api/auth/test/student', 'GET', null, studentToken);
    assert(sToS.statusCode === 200, 'Student can access /api/auth/test/student (200)');

    // Student accessing teacher route -> should fail (403)
    const sToT = await makeRequest('/api/auth/test/teacher', 'GET', null, studentToken);
    assert(sToT.statusCode === 403, 'Student is REJECTED from /api/auth/test/teacher (403 Forbidden)');

    // Student accessing admin route -> should fail (403)
    const sToA = await makeRequest('/api/auth/test/admin', 'GET', null, studentToken);
    assert(sToA.statusCode === 403, 'Student is REJECTED from /api/auth/test/admin (403 Forbidden)');

    // Teacher accessing teacher route -> should pass (200)
    const tToT = await makeRequest('/api/auth/test/teacher', 'GET', null, teacherToken);
    assert(tToT.statusCode === 200, 'Teacher can access /api/auth/test/teacher (200)');

    // Teacher accessing admin route -> should fail (403)
    const tToA = await makeRequest('/api/auth/test/admin', 'GET', null, teacherToken);
    assert(tToA.statusCode === 403, 'Teacher is REJECTED from /api/auth/test/admin (403 Forbidden)');

    // Admin accessing admin route -> should pass (200)
    const aToA = await makeRequest('/api/auth/test/admin', 'GET', null, adminToken);
    assert(aToA.statusCode === 200, 'Admin can access /api/auth/test/admin (200)');

    // 9. Unauthorized access without token
    console.log('\n[Test 9]: Testing Unauthenticated Requests (No token)...');
    const noTokenRes = await makeRequest('/api/auth/me', 'GET', null, null);
    assert(noTokenRes.statusCode === 401, 'Request without token rejected with 401 Unauthorized');

    console.log('\n====================================================');
    console.log(`   TEST RESULTS: ${passed} PASSED, ${failed} FAILED`);
    console.log('====================================================\n');

    process.exit(failed > 0 ? 1 : 0);
  } catch (error) {
    console.error('Error executing tests:', error);
    process.exit(1);
  }
}

runTests();
