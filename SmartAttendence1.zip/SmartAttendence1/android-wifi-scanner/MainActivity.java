package com.college.smartattendance.wifiscanner;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Android Native Wi-Fi Scanner Component for Smart Attendance System
 *
 * Scans physical Access Points (BSSID, RSSI, SSID) and sends them to
 * the Node.js backend for indoor positioning (Building -> Floor -> Room).
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "SmartAttendanceWiFi";
    private static final int PERMISSION_REQUEST_CODE = 101;
    // Replace with your Node.js server host/IP
    private static final String SERVER_URL = "http://10.0.2.2:5000/api/location/wifi-scan";

    private WifiManager wifiManager;
    private TextView statusTextView;
    private Button scanButton;

    private final BroadcastReceiver wifiScanReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            boolean success = intent.getBooleanExtra(WifiManager.EXTRA_RESULTS_UPDATED, false);
            if (success) {
                processScanResults();
            } else {
                statusTextView.setText("Scan failed or throttled by Android OS.");
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Simple programmatic layout or inflated view
        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);

        // Register Wi-Fi scan receiver
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        registerReceiver(wifiScanReceiver, intentFilter);

        checkAndRequestPermissions();
    }

    private void checkAndRequestPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_WIFI_STATE,
                            Manifest.permission.CHANGE_WIFI_STATE
                    },
                    PERMISSION_REQUEST_CODE
            );
        } else {
            startWifiScan();
        }
    }

    public void startWifiScan() {
        if (!wifiManager.isWifiEnabled()) {
            Toast.makeText(this, "Enabling Wi-Fi...", Toast.LENGTH_SHORT).show();
            wifiManager.setWifiEnabled(true);
        }
        boolean started = wifiManager.startScan();
        if (started) {
            Log.d(TAG, "Wi-Fi scan initiated successfully.");
        }
    }

    private void processScanResults() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        List<ScanResult> results = wifiManager.getScanResults();
        Log.d(TAG, "Detected " + results.size() + " Access Points nearby.");

        try {
            JSONObject payload = new JSONObject();
            payload.put("deviceModel", Build.MANUFACTURER + " " + Build.MODEL);
            payload.put("timestamp", System.currentTimeMillis());

            JSONArray scansArray = new JSONArray();
            for (ScanResult result : results) {
                JSONObject ap = new JSONObject();
                ap.put("bssid", result.BSSID);
                ap.put("ssid", result.SSID);
                ap.put("rssi", result.level);
                ap.put("frequency", result.frequency + " MHz");
                scansArray.put(ap);
            }
            payload.put("scans", scansArray);

            // Transmit scan data asynchronously to Node.js backend
            sendScansToBackend(payload.toString());

        } catch (Exception e) {
            Log.error(TAG, "Error formatting scan results", e);
        }
    }

    private void sendScansToBackend(final String jsonPayload) {
        new Thread(() -> {
            try {
                URL url = new URL(SERVER_URL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; utf-8");
                conn.setRequestProperty("Accept", "application/json");
                conn.setDoOutput(true);

                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = jsonPayload.getBytes(StandardCharsets.UTF_8);
                    os.write(input, 0, input.length);
                }

                int responseCode = conn.getResponseCode();
                Log.d(TAG, "Backend Response Code: " + responseCode);
                conn.disconnect();
            } catch (Exception e) {
                Log.e(TAG, "Failed to send scan payload to server: " + e.getMessage());
            }
        }).start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(wifiScanReceiver);
        } catch (Exception ignored) {}
    }
}
