/**
 * Native PC Hardware Wi-Fi Scanner Bridge
 *
 * Scans real physical Wi-Fi Access Points from your laptop/desktop Wi-Fi card
 * and posts the real BSSIDs/signals to the Node.js backend.
 *
 * Usage:
 *   node android-wifi-scanner/native-pc-bridge.js
 */

const { exec } = require('child_process');
const http = require('http');

const PORT = process.env.PORT || 5000;

function scanWindowsWifi() {
  return new Promise((resolve) => {
    exec('netsh wlan show networks mode=bssid', (error, stdout) => {
      if (error || !stdout) {
        console.warn('[PC Scanner] Could not run netsh or no Wi-Fi interface found.');
        return resolve([]);
      }

      const lines = stdout.split('\n');
      const aps = [];
      let currentSsid = '';

      for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.startsWith('SSID')) {
          const parts = trimmed.split(':');
          currentSsid = parts.slice(1).join(':').trim() || 'Hidden Network';
        } else if (trimmed.startsWith('BSSID')) {
          const parts = trimmed.split(':');
          const bssid = parts.slice(1).join(':').trim();
          aps.push({
            ssid: currentSsid,
            bssid: bssid.toUpperCase(),
            rssi: -65
          });
        } else if (trimmed.startsWith('Signal')) {
          const parts = trimmed.split(':');
          const pct = parseInt(parts[1].replace('%', '').trim(), 10) || 50;
          if (aps.length > 0) {
            aps[aps.length - 1].rssi = Math.round(pct / 2 - 100);
          }
        }
      }

      resolve(aps);
    });
  });
}

function makeApiRequest(path, method, body, token) {
  return new Promise((resolve, reject) => {
    const payload = body ? JSON.stringify(body) : null;
    const headers = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    if (payload) headers['Content-Length'] = Buffer.byteLength(payload);

    const req = http.request(
      {
        hostname: 'localhost',
        port: PORT,
        path,
        method,
        headers
      },
      (res) => {
        let data = '';
        res.on('data', (c) => (data += c));
        res.on('end', () => {
          try {
            resolve({ status: res.statusCode, body: JSON.parse(data) });
          } catch (e) {
            resolve({ status: res.statusCode, raw: data });
          }
        });
      }
    );
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

async function run() {
  console.log('==================================================');
  console.log('   NATIVE PC WI-FI HARDWARE SCANNER BRIDGE');
  console.log('==================================================\n');

  // Authenticate as test student to obtain Bearer JWT
  console.log('Authenticating with backend as student@college.edu...');
  const authRes = await makeApiRequest('/api/auth/login', 'POST', {
    email: 'student@college.edu',
    password: 'Student@12345',
    role: 'student'
  });

  if (authRes.status !== 200 || !authRes.body.token) {
    console.error('Authentication failed:', authRes.body);
    return;
  }
  const token = authRes.body.token;
  console.log('✓ Authenticated successfully with JWT.\n');

  console.log('Scanning local physical wireless adapter...\n');
  const scans = await scanWindowsWifi();
  console.log(`Detected ${scans.length} physical Wi-Fi Access Points nearby:`);
  scans.slice(0, 5).forEach((ap) => {
    console.log(`  - SSID: "${ap.ssid}" | BSSID: ${ap.bssid} | Signal: ${ap.rssi} dBm`);
  });

  if (scans.length === 0) {
    console.log('\n[Notice]: No physical Wi-Fi APs detected on wireless adapter.');
    return;
  }

  // Send hardware scans to backend
  console.log('\nTransmitting physical scan payload to /api/location/wifi-scan...');
  const sendRes = await makeApiRequest(
    '/api/location/wifi-scan',
    'POST',
    {
      deviceModel: 'PC Native Wireless Adapter (Windows netsh)',
      timestamp: new Date().toISOString(),
      scans
    },
    token
  );

  console.log(`✓ Backend Response (${sendRes.status}):`);
  console.log(JSON.stringify(sendRes.body, null, 2));
}

run();
