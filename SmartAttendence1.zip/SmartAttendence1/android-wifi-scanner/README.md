# Android Native Wi-Fi Scanner Component

## Why is a Native / Android Component Necessary?

Modern web browsers run inside a strict security sandbox (W3C / IETF specification) that restricts web JavaScript from reading OS-level Wi-Fi BSSIDs (hardware MAC addresses) and raw RSSI values directly from the user's Wi-Fi adapter. This restriction is designed to protect user privacy.

To overcome this technical reality, this Smart Attendance System provides two distinct pathways:

1. **Android Native Wi-Fi Scanner Component** (Real Hardware Sensor Mode): An Android application utilizing the Android `WifiManager` API to perform physical RF network scans and transmit detected BSSID/RSSI signatures to the Node.js backend API at `/api/location/wifi-scan`.
2. **Native PC Wi-Fi Card Bridge (`native-scanner-bridge.js`)**: A script that scans live physical Wi-Fi networks directly using the host operating system's wireless interface (e.g. `netsh wlan` on Windows) and streams actual hardware scans to the backend.
3. **Clearly Labelled DEMO WI-FI MODE**: An in-browser dropdown for development, classroom demonstrations, and viva examinations that simulates detected Access Points without claiming fake sensor data.

---

## Android App Architecture

- **Class**: `MainActivity.java`
- **Permissions Required** (in `AndroidManifest.xml`):
  - `android.permission.ACCESS_FINE_LOCATION` (Required by Android to scan Wi-Fi)
  - `android.permission.ACCESS_WIFI_STATE`
  - `android.permission.CHANGE_WIFI_STATE`
  - `android.permission.INTERNET`
  - `android.permission.NEARBY_WIFI_DEVICES` (Android 13+)

---

## How It Communicates with the Node.js Backend

1. Student logs into the Android app or provides their Student Token.
2. The Android component triggers `wifiManager.startScan()`.
3. A `BroadcastReceiver` intercepts `SCAN_RESULTS_AVAILABLE_ACTION`.
4. Scan results are formatted into JSON:
   ```json
   {
     "deviceModel": "Pixel / Samsung",
     "timestamp": "2026-09-23T19:20:00Z",
     "scans": [
       { "bssid": "00:1A:2B:3C:4D:01", "ssid": "CAMPUS-CS-LAB-101", "rssi": -62 },
       { "bssid": "00:1A:2B:3C:4D:02", "ssid": "CAMPUS-LECTURE-201", "rssi": -84 }
     ]
   }
   ```
5. The payload is sent via HTTP POST to:
   `http://<SERVER_IP>:5000/api/location/wifi-scan`
6. The Node.js indoor positioning engine resolves:
   `Building → Floor → Room/Classroom`
