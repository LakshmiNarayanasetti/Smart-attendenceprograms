// Smart Attendance System - Stage 1 Frontend Logic

document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const systemStatusEl = document.getElementById('system-status');
  const systemStatusText = document.getElementById('system-status-text');
  const alertBox = document.getElementById('alert-box');
  const authContainer = document.getElementById('auth-container');
  const sessionCard = document.getElementById('session-card');

  // Session elements
  const sessionUserName = document.getElementById('session-user-name');
  const sessionUserEmail = document.getElementById('session-user-email');
  const sessionUserRoll = document.getElementById('session-user-roll');
  const sessionUserEmp = document.getElementById('session-user-emp');
  const sessionUserDept = document.getElementById('session-user-dept');
  const sessionRollContainer = document.getElementById('session-roll-container');
  const sessionEmpContainer = document.getElementById('session-emp-container');
  const userRoleBadge = document.getElementById('user-role-badge');
  const btnLogout = document.getElementById('btn-logout');

  // Role tests
  const btnTestStudent = document.getElementById('btn-test-student');
  const btnTestTeacher = document.getElementById('btn-test-teacher');
  const btnTestAdmin = document.getElementById('btn-test-admin');
  const roleTestResult = document.getElementById('role-test-result');

  // Forms
  const loginForm = document.getElementById('login-form');
  const registerForm = document.getElementById('register-form');
  const loginEmailInput = document.getElementById('login-email');
  const loginPasswordInput = document.getElementById('login-password');

  // Helper buttons
  const btnFillAdmin = document.getElementById('btn-fill-admin');
  const btnFillTeacher = document.getElementById('btn-fill-teacher');

  // Tabs
  const tabButtons = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');

  // 1. Tab Switching
  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      tabButtons.forEach(b => b.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));
      btn.classList.add('active');
      const targetId = btn.getAttribute('data-tab');
      document.getElementById(targetId).classList.add('active');
      clearAlert();
    });
  });

  // 2. Alert Box Display
  function showAlert(message, type = 'error') {
    alertBox.textContent = message;
    alertBox.className = `alert-box ${type}`;
    alertBox.classList.remove('hidden');
  }

  function clearAlert() {
    alertBox.textContent = '';
    alertBox.className = 'alert-box hidden';
  }

  // 3. Health & Database Status Check
  async function checkHealth() {
    try {
      const res = await fetch('/api/health');
      const data = await res.json();
      if (res.ok && data.database === 'connected') {
        systemStatusEl.className = 'stage-badge online';
        systemStatusText.textContent = 'Server & MongoDB Connected';
      } else {
        systemStatusEl.className = 'stage-badge offline';
        systemStatusText.textContent = 'DB Not Connected';
      }
    } catch (err) {
      systemStatusEl.className = 'stage-badge offline';
      systemStatusText.textContent = 'Server Offline';
    }
  }

  // 4. Quick-fill helper buttons for test credentials
  btnFillAdmin.addEventListener('click', () => {
    document.querySelector('input[name="role"][value="admin"]').checked = true;
    loginEmailInput.value = 'admin@college.edu';
    loginPasswordInput.value = 'Admin@12345';
    showAlert('Admin credentials filled. Click "Sign In" to authenticate.', 'success');
  });

  btnFillTeacher.addEventListener('click', () => {
    document.querySelector('input[name="role"][value="teacher"]').checked = true;
    loginEmailInput.value = 'teacher@college.edu';
    loginPasswordInput.value = 'Teacher@12345';
    showAlert('Teacher credentials filled. Click "Sign In" to authenticate.', 'success');
  });

  // 5. Check if user is already logged in (Token in localStorage)
  async function checkExistingSession() {
    const token = localStorage.getItem('smart_attendance_token');
    if (!token) {
      showAuth();
      return;
    }

    try {
      const res = await fetch('/api/auth/me', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await res.json();
      if (res.ok && data.success) {
        showSession(data.user);
      } else {
        localStorage.removeItem('smart_attendance_token');
        showAuth();
      }
    } catch (err) {
      showAuth();
    }
  }

  function showSession(user) {
    authContainer.classList.add('hidden');
    sessionCard.classList.remove('hidden');

    sessionUserName.textContent = user.name;
    sessionUserEmail.textContent = user.email;
    sessionUserDept.textContent = user.department || 'Not Assigned';
    userRoleBadge.textContent = user.role.toUpperCase();

    if (user.role === 'student') {
      sessionRollContainer.classList.remove('hidden');
      sessionEmpContainer.classList.add('hidden');
      sessionUserRoll.textContent = user.rollNumber || 'N/A';
    } else {
      sessionRollContainer.classList.add('hidden');
      sessionEmpContainer.classList.remove('hidden');
      sessionUserEmp.textContent = user.employeeId || 'N/A';
    }

    roleTestResult.classList.add('hidden');
  }

  function showAuth() {
    sessionCard.classList.add('hidden');
    authContainer.classList.remove('hidden');
  }

  // 6. Registration Form Submission
  registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearAlert();

    const name = document.getElementById('reg-name').value.trim();
    const rollNumber = document.getElementById('reg-roll').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const department = document.getElementById('reg-dept').value.trim();
    const batch = document.getElementById('reg-batch').value.trim();
    const password = document.getElementById('reg-password').value;

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, rollNumber, email, department, batch, password })
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        showAlert(data.message || 'Registration failed.', 'error');
        return;
      }

      localStorage.setItem('smart_attendance_token', data.token);
      registerForm.reset();
      showSession(data.user);
    } catch (err) {
      showAlert('Network error occurred during registration.', 'error');
    }
  });

  // 7. Login Form Submission
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearAlert();

    const role = document.querySelector('input[name="role"]:checked').value;
    const email = loginEmailInput.value.trim();
    const password = loginPasswordInput.value;

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role, email, password })
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        showAlert(data.message || 'Login failed.', 'error');
        return;
      }

      localStorage.setItem('smart_attendance_token', data.token);
      loginForm.reset();
      showSession(data.user);
    } catch (err) {
      showAlert('Network error occurred during login.', 'error');
    }
  });

  // 8. Sign Out
  btnLogout.addEventListener('click', () => {
    localStorage.removeItem('smart_attendance_token');
    showAuth();
    showAlert('Signed out successfully.', 'success');
  });

  // 9. Role Guards Testing Handler
  async function testRoleAccess(targetRole) {
    const token = localStorage.getItem('smart_attendance_token');
    roleTestResult.classList.remove('hidden');
    roleTestResult.className = 'test-result-box';
    roleTestResult.textContent = `Testing access to /api/auth/test/${targetRole}...`;

    try {
      const res = await fetch(`/api/auth/test/${targetRole}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await res.json();

      if (res.ok && data.success) {
        roleTestResult.className = 'test-result-box alert-box success';
        roleTestResult.textContent = `✓ [200 OK] Authorized! Message: "${data.message}"`;
      } else {
        roleTestResult.className = 'test-result-box alert-box error';
        roleTestResult.textContent = `✗ [${res.status} ${res.statusText}] Rejected! Reason: "${data.message}"`;
      }
    } catch (err) {
      roleTestResult.className = 'test-result-box alert-box error';
      roleTestResult.textContent = `Request error: ${err.message}`;
    }
  }

  btnTestStudent.addEventListener('click', () => testRoleAccess('student'));
  btnTestTeacher.addEventListener('click', () => testRoleAccess('teacher'));
  btnTestAdmin.addEventListener('click', () => testRoleAccess('admin'));

  // Run initial checks
  checkHealth();
  checkExistingSession();
});
